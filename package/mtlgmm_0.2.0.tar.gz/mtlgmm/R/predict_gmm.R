#' @title Clustering new observations based on fitted binary GMM estimators.
#'
#' @description Clustering new observations based on fitted binary GMM estimators, which is an empirical version of Bayes classifier. See equation (13) in Tian, Y. et al. (2022).
#' @export
#' @param w the estimate of mixture proportion in the GMM. Numeric.
#' @param mu1 the estimate of Gaussian mean of the first cluster in the GMM. Should be a vector.
#' @param mu2 the estimate of Gaussian mean of the first cluster in the GMM. Should be a vector.
#' @param beta the estimate of the discriminant coefficient for the GMM. Should be a vector.
#' @param newx design matrix of new observations. Should be a matrix.
#' @return A vector of predicted labels of new observations.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' @examples
#' \donttest{
#' set.seed(23, kind = "L'Ecuyer-CMRG")
#' ## Consider a 5-task multi-task learning problem in the setting "MTL-1"
#' K <- 5
#' data_list <- data_generation(K = K, outlier_K = 1, simulation_no = "MTL-1", p = 10,
#'                              h = 1, n = 150)  # generate the data
#' x_train <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][1:50,]
#' }, simplify = FALSE)
#' x_test <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][-(1:50),]
#' }, simplify = FALSE)
#' y_test <- sapply(1:K, function(k){
#'   data_list$data$y[[k]][-(1:50)]
#' }, simplify = FALSE)
#'
#' fit <- mtlgmm(x = x_train, cv_nfolds = 5, initial_method = "EM", lambda_choice = "cv", ncores = 2,
#'               trim = 1/K)
#'
#' y_pred <- sapply(1:length(data_list$data$x), function(i){
#' predict_gmm(w = fit$w[i], mu1 = fit$mu1[, i], mu2 = fit$mu2[, i],
#' beta = fit$beta[, i], newx = x_test[[i]])
#' }, simplify = FALSE)
#' misclustering_error(y_pred[-data_list$data$outlier_index],
#' y_test[-data_list$data$outlier_index], type = "max")
#' }

predict_gmm <- function(w, mu1, mu2, beta, newx) {
  as.numeric(2-I(t(t(newx) - as.numeric(mu1+mu2)/2) %*% beta <= log((1-w)/w)))
}
