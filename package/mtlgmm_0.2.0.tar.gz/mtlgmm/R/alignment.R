#' @title Align the initializations for binary GMMs in the context of multi-task learning.
#' @description Align the initializations for binary GMMs in the context of multi-task learning. This function implements the two alignment algorithms (Algorithms 2 and 3) in Tian, Y. et al. (2022). This function is mainly for people to align the single-task initializations manually. The alignment procedure has been automatically implemented in function \code{mtlgmm} and \code{tlgmm}. So there is no need to call this function when fitting MTL-GMM or TL-GMM.
#' @export
#' @param beta the initializations for beta of all tasks. Should be a matrix of which each column is an "beta" estimate of a task.
#' @param method alignment method. Can be either "exhaustive" (Algorithm 2 in Tian, Y. et al. (2022)) or "greedy" (Algorithm 3 in Tian, Y. et al. (2022)). Default: "exhaustive"
#' @param num_replication the number of random replications. The final alignment will be chosen as the best result among these replications. See Remark 5 of Tian, Y. et al. (2022). Default = 1.
#' @param ncores the number of cores to use. Parallel computing is strongly suggested, specially when \code{lambda_choice} = "cv". Default: 1
#' @return the index of two clusters to become well-aligned, i.e. the "r_k" in Section 2.4.2 of Tian, Y. et al. (2022). The output can be passed to function \code{\link{alignment_swap}} to obtain the well-aligned intializations.
#' @note For examples, see part "fit signle-task GMMs" of examples in function \code{\link{mtlgmm}}.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y. et al. (2022). Unsupervised Multi-task and Transfer Learning on Gaussian Mixture Models. arXiv preprint arXiv:2209.15224.
#'

alignment <- function(beta, method = c("exhaustive", "greedy"), num_replication = 20, ncores = 1) {
  method <- match.arg(method)

  if (method == "exhaustive") {
    r.table <- as.matrix(expand.grid(rep(list(c(1,-1)), ncol(beta))))

  } else if (method == "greedy") {
    if (ncores == 1) {
      r.table <- t(sapply(1:num_replication, function(b){
        K <- ncol(beta)
        task_ind <- sample(K)
        r <- rep(1, K)
        beta_cur <- beta[, task_ind]
        for (k in 1:length(r)) {
          r.new <- r
          r.new[k] <- -r[k]
          if (score_beta(r.new, beta_cur) < score_beta(r, beta_cur)) {
            r <- r.new
          }
        }
        r_reordered <- sapply(1:K, function(k){
          r[task_ind == k]
        })
        r_reordered
      }))
    } else {
      registerDoParallel(ncores)
      r.table <- foreach(b = 1:num_replication, .combine = "rbind") %dopar% {
        K <- ncol(beta)
        task_ind <- sample(K)
        r <- rep(1, K)
        beta_cur <- beta[, task_ind]
        for (k in 1:length(r)) {
          r.new <- r
          r.new[k] <- -r[k]
          if (score_beta(r.new, beta_cur) < score_beta(r, beta_cur)) {
            r <- r.new
          }
        }
        r_reordered <- sapply(1:K, function(k){
          r[task_ind == k]
        })
        r_reordered
      }
      stopImplicitCluster()
    }

  }

  score.list <- sapply(1:nrow(r.table), function(i){
    score_beta(r.table[i, ], beta)
  })
  return(as.numeric(r.table[which.min(score.list), ]))


}
