#' @title Calculate the misclustering error given the predicted cluster labels in the binary GMMs, in the multi-task learning setting.
#'
#' @description  Calculate the misclustering error given the predicted cluster labels in the multi-cluster GMMs, in the multi-task learning setting.
#' @export
#' @param y_pred predicted cluster labels. A list of length K, where K is the number of tasks. Each component is a vector of predicted cluster labels for each task.
#' @param y_test true cluster labels. A list of length K, where K is the number of tasks. Each component is a vector of true cluster labels for each task.
#' @param type which type of the misclustering error rate to return. Can be either "max", "all", or "avg". Default: "max".
#' \itemize{
#' \item max: maximum of misclustering error rates on all tasks
#' \item all: a vector of misclustering error rates on all tasks
#' \item avg: average of misclustering error rates on all tasks
#' }
#' @return Scalar or vector. Depends on \code{type}. See the description above.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{data_generation}}, \code{\link{predict_gmm}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' @examples
#' \donttest{
#' set.seed(23, kind = "L'Ecuyer-CMRG")
#' ## Consider a 10-task multi-task learning problem in the setting "MTL-1"
#' K <- 10
#' data_list <- data_generation(K = K, outlier_K = 1, simulation_no = "MTL-1", p = 10,
#'                              h = 1, n = 150)  # generate the data
#' x_train <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][1:50,]
#' }, simplify = FALSE)
#' x_test <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][-(1:50),]
#' }, simplify = FALSE)
#' y_test <- sapply(1:K, function(k){
#'   data_list$data$y[[k]][-(1:50)]
#' }, simplify = FALSE)
#'
#' fit <- mtlgmm(x = x_train, cv_nfolds = 5, initial_method = "EM", lambda_choice = "cv", ncores = 2,
#'               trim = 1/K)
#'
#' y_pred <- sapply(1:length(data_list$data$x), function(i){
#' predict_gmm(w = fit$w[i], mu1 = fit$mu1[, i], mu2 = fit$mu2[, i],
#' beta = fit$beta[, i], newx = x_test[[i]])
#' }, simplify = FALSE)
#' misclustering_error(y_pred[-data_list$data$outlier_index],
#' y_test[-data_list$data$outlier_index], type = "max")
#' }


misclustering_error <- function(y_pred, y_test, type = c("max", "all", "avg")) {
  type <- match.arg(type)
  if (is.list(y_pred) && is.list(y_test)) {
    if (type == "max") {
      max(sapply(1:length(y_pred), function(k){
        min(mean(y_pred[[k]] != y_test[[k]]), mean((3-y_pred[[k]]) != y_test[[k]]))
      }))
    } else if (type == "all") {
      sapply(1:length(y_pred), function(k){
        min(mean(y_pred[[k]] != y_test[[k]]), mean((3-y_pred[[k]]) != y_test[[k]]))
      })
    } else if (type == "avg") {
      n.all <- length(Reduce("c", y_pred))
      wt <- sapply(1:length(y_pred), function(k){
        length(y_pred[[k]])/n.all
      })
      sum(wt*sapply(1:length(y_pred), function(k){
        min(mean(y_pred[[k]] != y_test[[k]]), mean((3-y_pred[[k]]) != y_test[[k]]))
      }))
    }
  } else { # then they have to be vectors of the same length
    min(mean(y_pred != y_test), mean((3-y_pred) != y_test))
  }
}
