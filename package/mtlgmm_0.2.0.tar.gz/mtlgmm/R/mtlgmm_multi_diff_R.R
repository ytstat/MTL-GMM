#' @title Fit multi-component Gaussian mixture models (GMMs) on multiple data sets under a multi-task learning (MTL) setting, when the numbers of clusters are different across tasks.
#'
#' @description It fits multi-component Gaussian mixture models (GMMs) on multiple data sets under a multi-task learning (MTL) setting, when the numbers of clusters are different across tasks. This function implements the extended method described in Section S.3.1.1 of Tian, Y. et al. (2022), which is an extension of function \code{\link{mtlgmm_multi}}.
#' @export
#' @param x design matrices from multiple data sets. Should be a list, of which each component is a \code{matrix} or \code{data.frame} object, representing the design matrix from each task.
#' @param step_size step size choice in proximal gradient method to solve each optimization problem in the revised EM algorithm (Algorithm 4 in Tian, Y. et al. (2022)), which can be either "lipschitz" or "fixed". Default = "lipschitz".
#' \itemize{
#' \item lipschitz: \code{eta_beta} will be chosen by the Lipschitz property of the gradient of objective function (without the penalty part). See Section 4.2 of Parikh, N., & Boyd, S. (2014).
#' \item fixed: \code{eta_beta} need to be specified
#' }
#' @param eta_beta step size in the proximal gradient method to learn beta (Step 12 of Algorithm 4 in Tian, Y. et al. (2022)). Default: 0.1. Only used when \code{step_size} = "fixed".
#' @param R the numbers of clusters for all tasks. Should be a vector of length K, where K is the number of tasks.
#' @param lambda_choice the choice of constants in the penalty parameter used in the optimization problems. See Algorithm 4 of Tian, Y. et al. (2022), which can be either "fixed" or "cv". Default: "cv".
#' \itemize{
#' \item cv: \code{cv_nfolds}, \code{cv_upper}, and \code{cv_length} need to be specified. Then \code{C_lambda} will be chosen in all combinations in \code{exp(seq(log(cv_lower/10), log(cv_upper/10), length.out = cv_length))} via cross-validation.
#' \item fixed: \code{C_lambda} need to be specified. See equations (7)-(12) in Tian, Y. et al. (2022).
#' }
#' @param cv_nfolds the number of cross-validation folds. Default: 10
#' @param cv_upper the upper bound of \code{lambda} values used in cross-validation. Default: 10
#' @param cv_lower the lower bound of \code{lambda} values used in cross-validation. Default: 0.01
#' @param cv_length the number of \code{lambda} values considered in cross-validation. Default: 10
#' @param C_lambda the initial value of C_lambda in Step 3 of Algorithm 1 in Tian, Y. et al. (2022). Default: 1
#' @param kappa the decaying rate used in equation (7)-(12) in Tian, Y. et al. (2022). Default: 1/3
#' @param tol maximum tolerance in all optimization problems. If the difference between last update and the current update is less than this value, the iterations of optimization will stop. Default: 1e-05
#' @param initial_method initialization method. This indicates the method to initialize the estimates of GMM parameters for each data set. Can be either "EM" or "kmeans". Default: "EM".
#' \itemize{
#' \item EM: the initial estimates of GMM parameters will be generated from the single-task EM algorithm. Will call \code{\link[mclust]{Mclust}} function in \code{mclust} package.
#' \item kmeans: the initial estimates of GMM parameters will be generated from the single-task k-means algorithm. Will call \code{\link[stats]{kmeans}} function in \code{stats} package.
#' }
#' @param alignment_method the alignment algorithm to use. See Section 2.4 of Tian, Y. et al. (2022). Can either be "exhaustive" or "greedy". Default: when \code{length(x)} <= 10, "exhaustive" will be used, otherwise "greedy" will be used.
#' \itemize{
#' \item exhaustive: exhaustive search algorithm (Algorithm 2 in Tian, Y. et al. (2022)) will be used.
#' \item greedy: greedy label swapping algorithm (Algorithm 3 in Tian, Y. et al. (2022)) will be used.
#' }
#' @param trim the proportion of trimmed datasets among all datasets (the same proportion from both bottom and top) in the cross-validation procedure of choosing tuning parameters. Setting it to a non-zero small value can help avoid the impact of outlier tasks on the choice of tuning parameters. Default: 0.1
#' @param iter_max the maximum iteration number of the revised EM algorithm (i.e. the parameter T in Algorithm 1 in Tian, Y. et al. (2022)). Default: 1000
#' @param iter_max_prox the maximum iteration number of the proximal gradient method. Default: 100
#' @param ncores the number of cores to use. Parallel computing is strongly suggested, specially when \code{lambda_choice} = "cv". Default: 1
#' @param cv_criterion the way used in cross-validation to aggregate the loss function from different tasks. Can be either "trimmed_mean" or "median". Default: "trimmed_mean". The trimming proportion is indicated by the parameter \code{trim}.
#' @param num_replication the number of random replications in the greedy alignment method. The final alignment will be chosen as the best result among these replications. Only used when \code{initial_method} = "greedy". See Remark 5 of Tian, Y. et al. (2022). Default = 50.
#' @return A list with the following components.
#' \item{w}{the estimate of mixture proportion in GMMs for each task. Will be a vector.}
#' \item{mu1}{the estimate of Gaussian mean in the first cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{mu2}{the estimate of Gaussian mean in the second cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{beta}{the estimate of the discriminant coefficient for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{Sigma}{the estimate of the common covariance matrix for each task. Will be a list, where each component represents the estimate for a task.}
#' \item{beta_bar}{the center estimate of beta. Will be a vector. See Algorithm 4 in Tian, Y. et al. (2022).}
#' \item{initial_beta}{the well-aligned initial estimate of beta of different tasks. Useful for the alignment problem in transfer learning. See Section 2.4 in Tian, Y. et al. (2022).}
#' \item{C_lambda}{the initial value of C_lambda.}
#' \item{C_lambda.list}{the list of C_lambda candidate values used in cross-validation when \code{lambda_choice} = "cv".}
#' @seealso \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' Parikh, N., & Boyd, S. (2014). Proximal algorithms. Foundations and trends in Optimization, 1(3), 127-239.
#'
#' @examples
#' \donttest{
#' # use cross-validation to choose the tuning parameters
#' # warning: can be quite slow, large "ncores" input is suggested!!
#' set.seed(0, kind = "L'Ecuyer-CMRG")
#' library(mclust)
## Consider a 10-task multi-task learning problem in the setting "MTL-diff-R"
#' K <- 10
#' p <- 6
#' # generate data
#' data_list <- data_generation(K = K, outlier_K = 1, h = 1, n = 100+500, p = p,
#'                              simulation_no = "MTL-diff-R", prob = c(0.2, 0.3, 0.5))
#' x_train <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][1:100,]
#' }, simplify = FALSE)
#' x_test <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][-(1:100),]
#' }, simplify = FALSE)
#' y_test <- sapply(1:K, function(k){
#'   data_list$data$y[[k]][-(1:100)]
#' }, simplify = FALSE)
#'
#' # fit MTL-GMM
#' fit <- mtlgmm_multi_diff_R(x = x_train, R = data_list$parameter$R, cv_nfolds = 5,
#'                            initial_method = "EM", lambda_choice = "cv", ncores = 2,
#'                            alignment_method = "greedy", trim = 1/K, num_replication = 20)
#'
#' # compare the performance with that of single-task estimators
#' # fit single-task GMMs
#' fitted_values <- initialize_multi(x_train, "EM", R = data_list$parameter$R, diff_R = TRUE)
#' pihat <- alignment_multi(fitted_values$mu, fitted_values$Sigma, method = "greedy",
#'                          num_replication = 20, ncores = 2, diff_R = TRUE)
#' fitted_values <- alignment_swap_multi(pihat, initial_value_list = fitted_values, diff_R = TRUE)
#'
#' R <- data_list$parameter$R
#' R_max <- max(R)
#'
#' error <- matrix(nrow = 2, ncol = 5,
#' dimnames = list(c("Single-task-GMM", "MTL-GMM"),
#' c("w", "mu", "beta", "Sigma", "Misclustering_error")))
#' error["Single-task-GMM", "w"] <- estimation_error_multi(
#'   fitted_values$w,
#'   data_list$parameter$w, "w", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#' error["MTL-GMM", "w"] <- estimation_error_multi(
#'   fit$w,
#'   data_list$parameter$w, "w", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#'
#' error["Single-task-GMM", "mu"] <- estimation_error_multi(
#'   fitted_values$mu, data_list$parameter$mu, "mu",
#'   outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#' error["MTL-GMM", "mu"] <- estimation_error_multi(
#'   fit$mu, data_list$parameter$mu, "mu", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#'
#' error["Single-task-GMM", "beta"]  <- estimation_error_multi(
#'   fitted_values$beta,
#'   list(data_list$parameter$mu, data_list$parameter$Sigma),
#'   "beta", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#' error["MTL-GMM", "beta"] <- estimation_error_multi(
#'   fit$beta,
#'   list(data_list$parameter$mu, data_list$parameter$Sigma),
#'   "beta", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#'
#' error["Single-task-GMM", "Sigma"] <- estimation_error_multi(
#'   fitted_values$Sigma,
#'   data_list$parameter$Sigma, "Sigma", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#' error["MTL-GMM", "Sigma"] <- estimation_error_multi(
#'   fit$Sigma,
#'   data_list$parameter$Sigma, "Sigma", outlier_index = data_list$data$outlier_index, diff_R = TRUE)
#'
#' # prediction on the test data
#' y_pred_single <- sapply(1:K, function(k){
#'   mu_k <- sapply(1:R_max, function(r){
#'     fitted_values$mu[[r]][, k]
#'  })
#'  mu_k <- mu_k[, apply(mu_k, 2, function(x){!anyNA(x)})]
#'  beta_k <- sapply(1:ncol(mu_k), function(r){
#'     solve(fitted_values$Sigma[[k]]) %*% (mu_k[, r] - mu_k[, 1])
#'   })
#'  w_k <- fitted_values$w[!is.na(fitted_values$w[, k]), k]
#'  predict_gmm_multi(w = w_k, mu = mu_k, beta = beta_k, newx = x_test[[k]])
#' }, simplify = FALSE)
#'
#' y_pred_mtlgmm <- sapply(1:K, function(k){
#'   mu_k <- sapply(1:R_max, function(r){
#'     fit$mu[[r]][, k]
#'   })
#'   mu_k <- mu_k[, apply(mu_k, 2, function(x){!anyNA(x)})]
#'   beta_k <- sapply(1:R_max, function(r){
#'     fit$beta[[r]][, k]
#'   })
#'   beta_k <- beta_k[, apply(beta_k, 2, function(x){!anyNA(x)})]
#'   w_k <- fit$w[!is.na(fit$w[, k]), k]
#'   predict_gmm_multi(w = w_k, mu = mu_k, beta = beta_k, newx = x_test[[k]])
#' }, simplify = FALSE)
#'
#' error["Single-task-GMM", "Misclustering_error"] <-
#' misclustering_error_multi(y_pred_single[-data_list$data$outlier_index],
#'                           y_test[-data_list$data$outlier_index],
#'                           R = R[-data_list$data$outlier_index], "max")
#' error["MTL-GMM", "Misclustering_error"] <-
#' misclustering_error_multi(y_pred_mtlgmm[-data_list$data$outlier_index],
#'                           y_test[-data_list$data$outlier_index],
#'                           R = R[-data_list$data$outlier_index], "max")
#'
#' # print the maximum estimation error and maximum prediction
#' # mis-clustering error (for non-outlier tasks)
#' print(error)
#' }
#'

mtlgmm_multi_diff_R <- function(x, step_size = c("lipschitz", "fixed"), eta_beta = 0.1, R,
                         lambda_choice = c("cv", "fixed"), cv_nfolds = 5, cv_upper = 10, cv_lower = 0.01, cv_length = 10, C_lambda=1,
                         kappa = 1/3, tol = 1e-5, initial_method = c("EM", "kmeans", "none"), alignment_method = c("exhaustive", "greedy"),
                         trim = 0.1, iter_max = 1000, iter_max_prox = 100, ncores = 1, cv_criterion = c("trimmed_mean", "median"),
                         num_replication = 50) {

  lambda_choice <- match.arg(lambda_choice)
  step_size <- match.arg(step_size)
  initial_method <- match.arg(initial_method)
  alignment_method <- match.arg(alignment_method)
  cv_criterion <- match.arg(cv_criterion)

  # basic parameters
  p <- ncol(x[[1]])
  K <- length(x)
  n <- sapply(1:K, function(k){nrow(x[[k]])})

  i <- NULL # just to avoid the error message "no visible binding for global variable 'i'"

  registerDoParallel(ncores)


  # initialization and alignment adjustment
  # ---------------------------------------------

  if (alignment_method == "exhaustive") {
    fitted_values <- initialize_multi(x, initial_method, R = R)
    pihat <- alignment_multi(fitted_values$mu, fitted_values$Sigma, method = "exhaustive", num_replication = 50, ncores = ncores)
    fitted_values <- alignment_swap_multi(pihat, initial_value_list = fitted_values)
  } else if (alignment_method == "greedy") {
    fitted_values <- initialize_multi(x, initial_method, R = R, diff_R = TRUE)
    pihat <- alignment_multi(fitted_values$mu, fitted_values$Sigma, method = "greedy", num_replication = min(num_replication, factorial(K)), ncores = ncores, diff_R = TRUE)
    fitted_values <- alignment_swap_multi(pihat, initial_value_list = fitted_values, diff_R = TRUE)
  }


  # MTL-EM
  # -------------------------
  R <- max(R)
  w <- fitted_values$w
  mu <- fitted_values$mu
  beta <- fitted_values$beta
  Sigma <- fitted_values$Sigma


  if (lambda_choice == "cv") {
    folds_index <- sapply(1:K, function(k){
      createFolds(1:n[k], k = cv_nfolds, list = TRUE)
    }, simplify = FALSE)

    if (cv_upper != "auto") {
      C_lambda.list <- exp(seq(log(cv_lower), log(cv_upper), length.out = cv_length))
    } else {
      C_lambda_up <- 1000
      C_lambda_low <- 0
      while(1) {
        C_lambda <- (C_lambda_up + C_lambda_low)/2
        beta_cur <- beta_fit_multi_diff_K(C_lambda, x, n, w, mu, beta, Sigma, p, K, R, tol, kappa, iter_max, iter_max_prox, step_size)
        u_diff <- max(sapply(2:R, function(r){
          beta_cur_mean <- rowMeans(beta_cur[[r]], na.rm = T)
          col_norm(beta_cur[[r]]-beta_cur_mean)
        }))

        if (u_diff <= 1e-2) {
          C_lambda_up <- C_lambda
        } else {
          C_lambda_low <- C_lambda
        }

        if(abs(C_lambda_up - C_lambda_low)<=1) {
          C_lambda <- C_lambda_up
          break
        }
        # print(c(C_lambda, u_diff))
      }
      # print("out!")
      C_lambda.list <- exp(seq(log(C_lambda/100*2), log(C_lambda*2), length.out = cv_length))
    }

    emp_logL <- foreach(i = 1:length(C_lambda.list), .combine = "rbind") %dopar% {
      # cat("\n", i, "-th lambda value\n", sep = "")

      sapply(1:cv_nfolds, function(j){
        # cat("\n", j, "-th fold\n", sep = "")
        # cat(j, "-th fold\n", sep = "")
        x.train <- sapply(1:K, function(k){
          x[[k]][-folds_index[[k]][[j]], ]
        }, simplify = FALSE)

        x.valid <- sapply(1:K, function(k){
          x[[k]][folds_index[[k]][[j]], ]
        }, simplify = FALSE)

        n.train <- sapply(1:K, function(k){nrow(x.train[[k]])})
        lambda.t <- C_lambda.list[i]*sqrt(max(n.train))

        for (l in 1:iter_max) {
          # print(l)
          lambda.t <- kappa*lambda.t + C_lambda.list[i]*sqrt(p+log(K))

          gamma <- sapply(1:K, function(k){
            gamma_table <- sapply(2:R, function(r){
              # sapply(1:n.train[k], function(i){
              #   exp(t(beta[[r]][, k]) %*% (x.train[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
              # })*w[r, k]
              exp(t(beta[[r]][, k]) %*% (t(x.train[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2))*w[r, k]
            })
            if (!any(is.infinite(gamma_table))) {
              gamma_table <- cbind(w[1, k], gamma_table)
              gamma_table[gamma_table == 0] <- 1e-8
              gamma_table/rowSums(gamma_table, na.rm = T)
            } else {
              log_gamma_table <- sapply(2:R, function(r){
                # sapply(1:n.train[k], function(i){
                #   t(beta[[r]][, k]) %*% (x.train[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2)
                # }) + log(w[r, k])
                t(beta[[r]][, k]) %*% (t(x.train[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2) + log(w[r, k])
              })
              for (i in 1:n.train[k]) {
                if (any(is.infinite(gamma_table[i, ]))) {
                  gamma_ind_sorted <- sort(log_gamma_table[i, ], decreasing = TRUE, index.return = TRUE, na.last = T)
                  if (gamma_ind_sorted$x[1] - gamma_ind_sorted$x[2] > 8) {
                    gamma_table[i, !is.na(gamma_table[i, ])] <- rep(0, sum(!is.na(gamma_table[i, ])))
                    gamma_table[i, gamma_ind_sorted$ix[1]] <- 1
                  } else {
                    log_gamma_table[i, ] <- log_gamma_table[i, ] - gamma_ind_sorted$x[2]
                    gamma_table[i, ] <- exp(log_gamma_table[i, ])
                  }
                }
              }
              gamma_table <- cbind(w[1, k], gamma_table)
              gamma_table[gamma_table == 0] <- 1e-8
              gamma_table/rowSums(gamma_table, na.rm = T)
            }

          }, simplify = FALSE)

          # gamma <- sapply(1:K, function(k){
          #   gamma_table <- sapply(2:R, function(r){
          #     sapply(1:n.train[k], function(i){
          #       exp(t(beta[[r]][, k]) %*% (x.train[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
          #     })*w[r, k]
          #   })
          #   gamma_table <- cbind(w[1, k], gamma_table)
          #   gamma_table/rowSums(gamma_table)
          # }, simplify = FALSE)



          # w
          w.old <- w
          w <- sapply(1:K, function(k){
            colMeans(gamma[[k]])
          })

          # mu
          mu.old <- mu
          mu <- sapply(1:R, function(r){
            sapply(1:K, function(k){
              colMeans(gamma[[k]][, r]*x.train[[k]])/w[r, k]
            })
          }, simplify = FALSE)


          # Sigma
          Sigma.old <- Sigma
          Sigma <- sapply(1:K, function(k){
            # Sigma.list <- sapply(1:R, function(r){
            #   t(x.train[[k]] - matrix(rep(mu[[r]][, k], n.train[k]), nrow =  n.train[k], byrow = T)) %*% diag(as.numeric(gamma[[k]][, r])) %*% (x.train[[k]] - matrix(rep(mu[[r]][, k], n.train[k]), nrow = n.train[k], byrow = T))/n.train[k]
            # }, simplify = FALSE)
            Sigma.list <- sapply(1:R, function(r){
              (t(x.train[[k]])-mu[[r]][, k]) %*% (as.numeric(gamma[[k]][, r])*t(t(x.train[[k]]) - mu[[r]][, k]))/n.train[k]
            }, simplify = FALSE)
            # Reduce("+", Sigma.list)
            Reduce("+", lapply(Sigma.list, function(S){S[is.na(S)] <- 0;S}))
          }, simplify = FALSE)



          # beta
          if (l == 1) {
            beta.bar <- sapply(1:R, function(r){
              rowMeans(beta[[r]], na.rm = T)
            })
            beta.t <- sapply(1:R, function(r){
              beta[[r]] - beta.bar[, r]
            }, simplify = FALSE)
          }
          beta.bar.old.last.round <- beta.bar
          beta.bar.old <- beta.bar

          if (step_size == "lipschitz") {
            eta_beta.list <- sapply(1:K, function(k){
              1/(2*norm(Sigma[[k]], "2"))
            })
          } else if (step_size == "fixed") {
            eta_beta.list <- rep(eta_beta, K)
          }
          beta.t.old <- beta.t
          for (r in 2:R) {
            for (o in 1:iter_max_prox) {
              beta.t[[r]] <- sapply(1:K, function(k){
                eta_beta <- eta_beta.list[k]
                del <- beta.t[[r]][, k] - eta_beta*(Sigma[[k]] %*% (beta.t[[r]][, k] + beta.bar[, r]) + mu[[1]][, k] - mu[[r]][, k])
                max(1-(eta_beta*lambda.t/sqrt(n.train[k]))/sqrt(sum(del^2, na.rm = T)), 0)*del
              })

              Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
                n.train[k]*Sigma[[k]]*as.numeric(!is.na(w[r, k]))
              }, simplify = FALSE))

              vector.weighted.sum <- rowSums(sapply(1:K, function(k){
                n.train[k]*(-Sigma[[k]]%*%beta.t[[r]][, k] - mu[[1]][, k] + mu[[r]][, k])*as.numeric(!is.na(w[r, k]))
              }), na.rm = T)


              beta.bar.old[, r] <- beta.bar[, r]
              beta.bar[, r] <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

              if (max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])) <= tol) {
                break
              }
              # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))

            }
          }


          beta.old <- beta
          beta <- sapply(1:R, function(r){
            beta.t[[r]] + beta.bar[, r]
          }, simplify = FALSE)

          mu_err <- max(sapply(1:R, function(r){
            col_norm(mu[[r]] - mu.old[[r]])
          }))
          beta_err <- max(sapply(2:R, function(r){
            col_norm(beta[[r]] - beta.old[[r]])
          }))

          w_err <- vec_max_norm(w-w.old)

          Sigma.err <- max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")}))
          # check whether to terminate the interation process or not
          error <- max(w_err, mu_err, beta_err, Sigma.err, col_norm(beta.bar - beta.bar.old.last.round))

          if (error <= tol) {
            break
          }
        }
        loss <- sort(sapply(1:K, function(k){
          sum(log(rowSums(sapply(1:R, function(r){
            w[r, k]*safe_dmvnorm(data = x.valid[[k]], mean = mu[[r]][, k], sigma = Sigma[[k]])
          }))), na.rm = T)
        }), decreasing = FALSE)

        trim_ind <- quantile(1:K, c(trim, 1-trim), type = 1)
        if (cv_criterion == "trimmed_mean") {
          sum(loss[-c(1:floor(trim_ind[1]), ceiling(trim_ind[2]+1):K)])
        } else if (cv_criterion == "median") {
          median(loss)
        }
      })
    }

    C_lambda <- C_lambda.list[which.max(rowMeans(emp_logL))]
    lambda_choice <- "fixed" # run the algorithm again with optimal choice of parameters
    # print("just finished!")
  }

  if (lambda_choice == "fixed") {
    lambda.t <- C_lambda*sqrt(max(n))

    for (l in 1:iter_max) {

      lambda.t <- kappa*lambda.t + C_lambda*sqrt(p+log(K))

      gamma <- sapply(1:K, function(k){
        gamma_table <- sapply(2:R, function(r){
          # sapply(1:n[k], function(i){
          #   exp(t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
          # })*w[r, k]
          exp(t(beta[[r]][, k]) %*% (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2))*w[r, k]
        })
        if (!any(is.infinite(gamma_table))) {
          gamma_table <- cbind(w[1, k], gamma_table)
          gamma_table[gamma_table == 0] <- 1e-8
          gamma_table/rowSums(gamma_table, na.rm = T)
        } else {
          log_gamma_table <- sapply(2:R, function(r){
            # sapply(1:n[k], function(i){
            #   t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2)
            # }) + log(w[r, k])
              t(beta[[r]][, k]) %*% (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2) + log(w[r, k])
          })
          for (i in 1:n[k]) {
            if (any(is.infinite(gamma_table[i, ]))) {
              gamma_ind_sorted <- sort(log_gamma_table[i, ], decreasing = TRUE, index.return = TRUE, na.last = T)
              if (gamma_ind_sorted$x[1] - gamma_ind_sorted$x[2] > 8) {
                gamma_table[i, !is.na(gamma_table[i, ])] <- rep(0, sum(!is.na(gamma_table[i, ])))
                gamma_table[i, gamma_ind_sorted$ix[1]] <- 1
              } else {
                log_gamma_table[i, ] <- log_gamma_table[i, ] - gamma_ind_sorted$x[2]
                gamma_table[i, ] <- exp(log_gamma_table[i, ])
              }
            }
          }
          gamma_table <- cbind(w[1, k], gamma_table)
          gamma_table[gamma_table == 0] <- 1e-8
          gamma_table/rowSums(gamma_table, na.rm = T)
        }

      }, simplify = FALSE)



      # w
      w.old <- w
      w <- sapply(1:K, function(k){
        colMeans(gamma[[k]])
      })
      # print(w)
      # cat("\n")

      # mu1 and mu2
      mu.old <- mu
      mu <- sapply(1:R, function(r){
        sapply(1:K, function(k){
          colMeans(gamma[[k]][, r]*x[[k]])/w[r, k]
        })
      }, simplify = FALSE)


      # Sigma
      Sigma.old <- Sigma
      Sigma <- sapply(1:K, function(k){
        # Sigma.list <- sapply(1:R, function(r){
        #   t(x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]][, r])) %*% (x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow = n[k], byrow = T))/n[k]
        # }, simplify = FALSE)
        Sigma.list <- sapply(1:R, function(r){
          (t(x[[k]])-mu[[r]][, k]) %*% (as.numeric(gamma[[k]][, r])*t(t(x[[k]]) - mu[[r]][, k]))/n[k]
        }, simplify = FALSE)

        # Sigma.list <- lapply(Sigma.list, function(S){S[is.na(S)] <- 0;S})
        # Sigma.avg <- matrix(0, nrow = p, ncol = p)
        # for (S in Sigma.list) {
        #   Sigma.avg <- Sigma.avg + S
        # }
        # Sigma.avg
        Reduce("+", lapply(Sigma.list, function(S){S[is.na(S)] <- 0;S}))
      }, simplify = FALSE)



      # beta
      if (l == 1) {
        beta.bar <- sapply(1:R, function(r){
          rowMeans(beta[[r]], na.rm = T)
        })
        beta.t <- sapply(1:R, function(r){
          beta[[r]] - beta.bar[, r]
        }, simplify = FALSE)
      }
      beta.bar.old.last.round <- beta.bar
      beta.bar.old <- beta.bar

      if (step_size == "lipschitz") {
        eta_beta.list <- sapply(1:K, function(k){
          1/(2*norm(Sigma[[k]], "2"))
        })
      } else if (step_size == "fixed") {
        eta_beta.list <- rep(eta_beta, K)
      }

      beta.t.old <- beta.t
      for (r in 2:R) {
        for (o in 1:iter_max_prox) {
          beta.t[[r]] <- sapply(1:K, function(k){
            eta_beta <- eta_beta.list[k]
            del <- beta.t[[r]][, k] - eta_beta*(Sigma[[k]] %*% (beta.t[[r]][, k] + beta.bar[, r]) + mu[[1]][, k] - mu[[r]][, k])
            max(1-(eta_beta*lambda.t/sqrt(n[k]))/sqrt(sum(del^2, na.rm = T)), 0)*del
          })

          Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
            n[k]*Sigma[[k]]*as.numeric(!is.na(w[r, k]))
          }, simplify = FALSE))

          vector.weighted.sum <- rowSums(sapply(1:K, function(k){
            n[k]*(-Sigma[[k]]%*%beta.t[[r]][, k] - mu[[1]][, k] + mu[[r]][, k])
          }), na.rm = T)


          beta.bar.old[, r] <- beta.bar[, r]
          beta.bar[, r] <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

          if (is.na(max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])))) {
            print("wrong!")
          }
          if (max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])) <= tol) {
            break
          }
          # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))

        }
      }


      beta.old <- beta
      beta <- sapply(1:R, function(r){
        beta.t[[r]] + beta.bar[, r]
      }, simplify = FALSE)

      mu_err <- max(sapply(1:R, function(r){
        col_norm(mu[[r]] - mu.old[[r]])
      }))
      beta_err <- max(sapply(2:R, function(r){
        col_norm(beta[[r]] - beta.old[[r]])
      }))

      w_err <- vec_max_norm(w-w.old)

      Sigma.err <- max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")}))
      # check whether to terminate the interation process or not
      error <- max(w_err, mu_err, beta_err, Sigma.err, col_norm(beta.bar - beta.bar.old.last.round))

      if (error <= tol) {
        break
      }
      # print(c(l, error))
    }
  }


  stopImplicitCluster()
  # stopCluster(cl)

  delta <- sapply(1:K, function(k){
    sapply(1:R, function(r){
      sum(beta[[r]][, k]*(mu[[r]][, k] + mu[[1]][, k])/2)
    })
  })

  return(list(w = w, mu = mu, beta = beta, delta = delta, Sigma = Sigma, beta_bar = beta.bar,
              initial_beta = fitted_values$beta, C_lambda = C_lambda))


}
