#' @title Calculate the misclustering error given the predicted cluster labels in the multi-cluster GMMs, in the multi-task learning setting.
#'
#' @description  Calculate the misclustering error given the predicted cluster labels in the multi-cluster GMMs, in the multi-task learning setting.
#' @export
#' @param y_pred predicted cluster labels
#' @param y_test true cluster labels
#' @param R the number of clusters for tasks. If all tasks share the same number of clusters, \code{R} can be a number. Otherwise, \code{R} should be a vector of length K, where K is the number of tasks.
#' @param type which type of the misclustering error rate to return. Can be either "max", "all", or "avg". Default: "max".
#' \itemize{
#' \item max: maximum of misclustering error rates on all tasks
#' \item all: a vector of misclustering error rates on all tasks
#' \item avg: average of misclustering error rates on all tasks
#' }
#' @return Depends on \code{type}.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{data_generation}}, \code{\link{predict_gmm}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' @examples
#' \donttest{
#' set.seed(23, kind = "L'Ecuyer-CMRG")
## Consider a 5-task multi-task learning problem in the setting "MTL-2"
#' K <- 5
#' p <- 6
#' R <- 4
#' # generate data
#' data_list <- data_generation(K = K, outlier_K = 1, h = 1,
#' n = 100+500, p = 6, simulation_no = "MTL-2")  # generate the data
#' x_train <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][1:100,]
#' }, simplify = FALSE)
#' x_test <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][-(1:100),]
#' }, simplify = FALSE)
#' y_test <- sapply(1:K, function(k){
#'   data_list$data$y[[k]][-(1:100)]
#' }, simplify = FALSE)
#'
#' fit <- mtlgmm_multi(x = x_train, cv_nfolds = 5, initial_method = "EM",
#' lambda_choice = "cv", ncores =2, alignment_method = "greedy",
#' trim = 1/K, num_replication = 20, R = 4)
#'
#' y_pred <- sapply(1:K, function(k){
#'  mu_k <- sapply(1:R, function(r){
#'    fit$mu[[r]][, k]
#'  })
#'  beta_k <- sapply(1:R, function(r){
#'    fit$beta[[r]][, k]
#'  })
#'  predict_gmm_multi(w = fit$w[, k], mu = mu_k, beta = beta_k, newx = x_test[[k]])
#' }, simplify = FALSE)
#' misclustering_error_multi(y_pred[-data_list$data$outlier_index],
#' y_test[-data_list$data$outlier_index], R, type = "max")
#' }

misclustering_error_multi <- function(y_pred, y_test, R, type = c("max", "all", "avg")) {
  type <- match.arg(type)
  if (length(R) == 1) {
    pi_all <- permutations(R, R)
    if (is.list(y_pred) && is.list(y_test)) {
      if (type == "max") {
        max(sapply(1:length(y_pred), function(k){
          min(sapply(1:nrow(pi_all), function(i){
            mean(y_pred[[k]] != pi_all[i, y_test[[k]]])
          }))
        }))
      } else if (type == "all") {
        sapply(1:length(y_pred), function(k){
          min(sapply(1:nrow(pi_all), function(i){
            mean(y_pred[[k]] != pi_all[i, y_test[[k]]])
          }))
        })
      } else if (type == "avg") {
        n.all <- length(Reduce("c", y_pred))
        wt <- sapply(1:length(y_pred), function(k){
          length(y_pred[[k]])/n.all
        })
        sum(wt*sapply(1:length(y_pred), function(k){
          min(sapply(1:nrow(pi_all), function(i){
            mean(y_pred[[k]] != pi_all[i, y_test[[k]]])
          }))
        }))
      }
    }
  } else if (length(R) > 1) {
    if (is.list(y_pred) && is.list(y_test)) {
      if (type == "max") {
        max(sapply(1:length(y_pred), function(k){
          pi_all <- permutations(R[k], R[k])
          min(sapply(1:nrow(pi_all), function(i){
            mean(y_pred[[k]] != pi_all[i, y_test[[k]]])
          }))
        }))
      } else if (type == "all") {
        sapply(1:length(y_pred), function(k){
          pi_all <- permutations(R[k], R[k])
          min(sapply(1:nrow(pi_all), function(i){
            mean(y_pred[[k]] != pi_all[i, y_test[[k]]])
          }))
        })
      } else if (type == "avg") {
        n.all <- length(Reduce("c", y_pred))
        wt <- sapply(1:length(y_pred), function(k){
          length(y_pred[[k]])/n.all
        })
        sum(wt*sapply(1:length(y_pred), function(k){
          pi_all <- permutations(R[k], R[k])
          min(sapply(1:nrow(pi_all), function(i){
            mean(y_pred[[k]] != pi_all[i, y_test[[k]]])
          }))
        }))
      }
    }
  }

}

