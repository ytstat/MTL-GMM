#' @title Caluclate the estimation error of binary GMM parameters under the MTL setting (the worst performance among all non-outlier tasks).
#'
#' @description Caluclate the estimation error of GMM parameters under the MTL setting (the worst performance among all non-outlier tasks). Euclidean norms are used.
#' @export
#' @param estimated_value estimate of GMM parameters. The form of input depends on the parameter \code{parameter}.
#' @param true_value true values of GMM parameters. The form of input depends on the parameter \code{parameter}.
#' @param parameter which parameter to calculate the estimation error for. Can be "w", "mu", "beta", or "Sigma".
#' \itemize{
#' \item w: the Gaussian mixture proportions. Both \code{estimated_value} and \code{true_value} require an input of a K-dimensional vector, where K is the number of tasks. Each element in the vector is an "w" (estimate or true value) for each task.
#' \item mu: Gaussian mean parameters. Both \code{estimated_value} and \code{true_value} require an input of a list of two p-by-K matrices, where p is the dimension of Gaussian distribution and K is the number of tasks. Each column of the matrix is a "mu1" or "mu2" (estimate or true value) for each task.
#' \item beta: discriminant coefficients. Both \code{estimated_value} and \code{true_value} require an input of a p-by-K matrix, where p is the dimension of Gaussian distribution and K is the number of tasks. Each column of the matrix is a "beta" (estimate or true value) for each task.
#' \item delta: part of the intercept in the decision boundary. Both \code{estimated_value} and \code{true_value} require an input of a K-dimensional vector, where K is the number of tasks. Each element in the vector is an "delta" (estimate or true value) for each task.
#' \item Sigma: Gaussian covariance matrices. Both \code{estimated_value} and \code{true_value} require an input of a list of K p-by-p matrices, where p is the dimension of Gaussian distribution and K is the number of tasks. Each matrix in the list is a "Sigma" (estimate or true value) for each task.
#' }
#' @param outlier_index the index of outlier tasks. Default: \code{NULL} (i.e., no outliers).
#' @return the largest estimation error among all tasks.
#' @note For examples, see examples in function \code{\link{mtlgmm}}.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'

estimation_error <- function(estimated_value, true_value, parameter = c("w", "mu", "beta", "delta", "Sigma"), outlier_index = NULL) {
  if (parameter == "w") {
    K <- length(estimated_value)
    v <- max(sapply(setdiff(1:K, outlier_index), function(k){
      min(abs(estimated_value[k]-true_value[k]), abs(1-estimated_value[k]-true_value[k]))
    }))
    return(v)
    # return(min(vec_max_norm(estimated_value-true_value), vec_max_norm(1-estimated_value-true_value)))
  } else if (parameter == "mu") {
    K <- ncol(estimated_value[[1]])
    v <- max(sapply(setdiff(1:K, outlier_index), function(k){
      min(max(vec_norm(estimated_value[[1]][, k]-true_value[[1]][, k]), vec_norm(estimated_value[[2]][, k]-true_value[[2]][, k])),
          max(vec_norm(estimated_value[[2]][, k]-true_value[[1]][, k]), vec_norm(estimated_value[[1]][, k]-true_value[[2]][, k])))
    }))
    return(v)
    # alm1 <- max(col_norm(estimated_value[[1]]-true_value[[1]]), col_norm(estimated_value[[2]]-true_value[[2]]))
    # alm2 <- max(col_norm(estimated_value[[1]]-true_value[[2]]), col_norm(estimated_value[[2]]-true_value[[1]]))
    # return(min(alm1, alm2))
  } else if (parameter == "beta") {
    K <- ncol(estimated_value)
    v <- max(sapply(setdiff(1:K, outlier_index), function(k){
      min(vec_norm(estimated_value[, k]-true_value[, k]), vec_norm(estimated_value[, k]+true_value[, k]))
    }))
    return(v)
  } else if (parameter == "delta") {
    K <- length(estimated_value)
    v <- max(sapply(setdiff(1:K, outlier_index), function(k){
      min(abs(estimated_value[k]-true_value[k]), abs(estimated_value[k]+true_value[k]))
    }))
    return(v)
    # return(min(vec_max_norm(estimated_value-true_value), vec_max_norm(estimated_value+true_value)))
  } else if (parameter == "Sigma") {
    K <- length(estimated_value)
    v <- max(sapply(setdiff(1:K, outlier_index), function(k){
      norm(estimated_value[[k]]-true_value[[k]], "2")
    }))
    return(v)
  }
}
