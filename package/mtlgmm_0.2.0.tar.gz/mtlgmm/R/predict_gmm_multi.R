#' @title Clustering new observations based on fitted multi-component GMM estimators.
#'
#' @description Clustering new observations based on fitted multi-component GMM estimators, which is an empirical version of Bayes classifier. See equation (13) in Tian, Y. et al. (2022).
#' @export
#' @param w the estimate of mixture proportion in the GMM. Should be a vector of length R, where R is the number of clusters.
#' @param mu the estimate of Gaussian mean of the first cluster in the GMM. Should be a p-by-R matrix, where p is the number of features and R is the number of clusters.
#' @param beta the estimate of the discriminant coefficient for the GMM. Should be a p-by-R matrix, where p is the number of features and R is the number of clusters.
#' @param newx design matrix of new observations. Should be a matrix.
#' @return A vector of predicted labels of new observations.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' @examples
#' \donttest{
#' set.seed(23, kind = "L'Ecuyer-CMRG")
## Consider a 5-task multi-task learning problem in the setting "MTL-2"
#' K <- 5
#' p <- 6
#' R <- 4
#' # generate data
#' data_list <- data_generation(K = K, outlier_K = 1, h = 1,
#' n = 100+500, p = 6, simulation_no = "MTL-2")  # generate the data
#' x_train <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][1:100,]
#' }, simplify = FALSE)
#' x_test <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][-(1:100),]
#' }, simplify = FALSE)
#' y_test <- sapply(1:K, function(k){
#'   data_list$data$y[[k]][-(1:100)]
#' }, simplify = FALSE)
#'
#' fit <- mtlgmm_multi(x = x_train, cv_nfolds = 5, initial_method = "EM",
#'                     lambda_choice = "cv", ncores = 2,
#'                     alignment_method = "greedy", trim = 1/K, num_replication = 20, R = 4)
#'
#' y_pred <- sapply(1:K, function(k){
#'  mu_k <- sapply(1:R, function(r){
#'    fit$mu[[r]][, k]
#'  })
#'  beta_k <- sapply(1:R, function(r){
#'    fit$beta[[r]][, k]
#'  })
#'  predict_gmm_multi(w = fit$w[, k], mu = mu_k, beta = beta_k, newx = x_test[[k]])
#' }, simplify = FALSE)
#' misclustering_error_multi(y_pred[-data_list$data$outlier_index],
#' y_test[-data_list$data$outlier_index], R, type = "max")
#' }

predict_gmm_multi <- function(w, mu, beta, newx) {
  sapply(1:nrow(newx), function(i){
    which.max(sapply(1:length(w), function(r){
      log(w[r]) + beta[, r] %*% (matrix(as.numeric(newx[i, ]), ncol = 1) - (mu[, r] + mu[, 1])/2)
    }))
  })

}
