#' @title Align the initializations for multi-component GMMs in the context of multi-task learning.
#' @description Align the initializations for multi-component GMMs in the context of multi-task learning. This function implements the two alignment algorithms (Algorithms 5 and 6) in Tian, Y. et al. (2022). This function is mainly for people to align the single-task initializations manually. The alignment procedure has been automatically implemented in function \code{mtlgmm} and \code{tlgmm}. So there is no need to call this function when fitting MTL-GMM or TL-GMM.
#' @export
#' @param mu the initializations for mu of all tasks. Should be a list of matrices, where each column is a "mu" estimate of a cluster in each task.
#' @param Sigma the initializations for Sigma of all tasks. Should be a list of matrices, where each matrix is a "Sigma" estimate of a task.
#' @param method alignment method. Can be either "exhaustive" (Algorithm 5 in Tian, Y. et al. (2022)) or "greedy" (Algorithm 6 in Tian, Y. et al. (2022)). Default: "greedy".
#' @param num_replication the number of random replications. The final alignment will be chosen as the best result among these replications. See Remark 5 of Tian, Y. et al. (2022). Default = 1.
#' @param ncores the number of cores to use. Parallel computing is strongly suggested, specially when \code{lambda_choice} = "cv". Default: 1
#' @param diff_R whether the cluster numbers of tasks are different. Default: \code{FALSE}. The case that it is TRUE corresponds to the extension in Section S.3.1 in the supplement of Tian, Y. et al. (2022).
#' @return the index of two clusters to become well-aligned, i.e. the "r_k" in Section 2.4.2 of Tian, Y. et al. (2022). The output can be passed to function \code{\link{alignment_swap_multi}} to obtain the well-aligned intializations.
#' @note For examples, see part "fit signle-task GMMs" of examples in function \code{\link{mtlgmm_multi}}.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y. et al. (2022). Unsupervised Multi-task and Transfer Learning on Gaussian Mixture Models. arXiv preprint arXiv:2209.15224.
#'

alignment_multi <- function(mu, Sigma, method = c("exhaustive", "greedy"), num_replication = 50, ncores = 1, diff_R = FALSE) {
  i <- NULL # just to avoid the error message "no visible binding for global variable 'i'"

  if (!diff_R) {
    R <- length(mu)
    K <- ncol(mu[[1]])

    if (method == "exhaustive") {
      pihat.index.table <- permutations(R, R)
      task.index.table <- expand.grid(rep(list(1:nrow(pihat.index.table)), K))
      if (ncores == 1) {
        score.list <- sapply(1:nrow(task.index.table), function(i){
          pihat.table <- sapply(1:K, function(k){
            pihat.index.table[task.index.table[i, k], ]
          })
          score_beta_multi(pihat.table, mu, Sigma)
        })
      } else {
        registerDoParallel(ncores)
        score.list <- foreach(i = 1:nrow(task.index.table), .combine = "c") %dopar% {
          pihat.table <- sapply(1:K, function(k){
            pihat.index.table[task.index.table[i, k], ]
          })
          score_beta_multi(pihat.table, mu, Sigma)
        }
        stopImplicitCluster()
      }
      i0 <- which.min(score.list)
      pihat.table <- sapply(1:K, function(k){
        pihat.index.table[task.index.table[i0, k], ]
      })
      return(pihat.table)
    } else if (method == "greedy") { # not changed yet
      pihat.index.table <- permutations(R, R)
      if (ncores == 1) {
        pihat.list <- sapply(1:num_replication, function(b){
          task_ind <- sample(K)
          pihat.table <- matrix(1:R)
          for (k in 2:K) {
            mu.cur <- sapply(1:R, function(r){
              mu[[r]][, task_ind[1:k]]
            }, simplify = FALSE)
            score.list <- sapply(1:nrow(pihat.index.table), function(i){
              pihat.table.cur <- cbind(pihat.table, pihat.index.table[i, ])
              score_beta_multi(pihat.table.cur, mu.cur, Sigma)
            })
            i0 <- which.min(score.list)
            pihat.table <- cbind(pihat.table, pihat.index.table[i0, ])
          }
          pihat.reordered <- sapply(1:K, function(k){
            pihat.table[, task_ind == k]
          })
          pihat.reordered
        }, simplify = FALSE)

      } else { # ncores > 1
        registerDoParallel(ncores)
        pihat.list <- foreach(b = 1:num_replication) %dopar% {
          task_ind <- sample(K)
          pihat.table <- matrix(1:R)
          for (k in 2:K) {
            mu.cur <- sapply(1:R, function(r){
              mu[[r]][, task_ind[1:k]]
            }, simplify = FALSE)
            score.list <- sapply(1:nrow(pihat.index.table), function(i){
              pihat.table.cur <- cbind(pihat.table, pihat.index.table[i, ])
              score_beta_multi(pihat.table.cur, mu.cur, Sigma)
            })
            i0 <- which.min(score.list)
            pihat.table <- cbind(pihat.table, pihat.index.table[i0, ])
          }
          pihat.reordered <- sapply(1:K, function(k){
            pihat.table[, task_ind == k]
          })
          pihat.reordered
        }
        stopImplicitCluster()
      }
    }
  } else { # diff_R = TRUE
    if (method == "greedy") {
      K <- length(mu)
      R <- sapply(1:K, function(k){ncol(mu[[k]])})
      R_max <- max(R)
      index_by_R <- sapply(R_max:2, function(r){
        which(R == r)
      }, simplify = F)
      if (ncores == 1) {
        pihat.list <- sapply(1:num_replication, function(b){
          # task_ind <- sample(K)
          task_ind <- Reduce(c, lapply(index_by_R, function(x){
            if (length(x) > 1) {
              sample(x)
            } else {
              x
            }
          }))
          pihat.list.b <- sapply(1:R[task_ind[1]], function(o){
            pihat.table <- rep(NA, R_max)
            pihat.table[1:R[task_ind[1]]] <- 1:R[task_ind[1]]
            # change the reference class for the 1st task
            pihat.table[o] <- 1
            pihat.table[1] <- o
            for (k in 2:K) {
              pihat.index0 <- permutations(n = R_max, r = R[task_ind[k]], v = 1:R_max)
              pihat.index.table <- t(sapply(1:nrow(pihat.index0), function(i){
                match(1:R_max, pihat.index0[i, ])
              }))
              pihat.index.table <- pihat.index.table[!is.na(pihat.index.table[, 1]), ]

              mu.cur <- mu[task_ind[1:k]]
              Sigma.cur <- Sigma[task_ind[1:k]]
              score.list <- sapply(1:nrow(pihat.index.table), function(i){
                pihat.table.cur <- rbind(pihat.table, pihat.index.table[i, ])
                score_beta_multi_diff_R(pihat.table.cur, mu.cur, Sigma.cur)
              })
              i0 <- which.min(score.list)
              pihat.table <- rbind(pihat.table, pihat.index.table[i0, ])
            }
            pihat.table
          }, simplify = FALSE)
          # select the optimal order from R[k]
          score.list <- sapply(1:R[task_ind[1]], function(o){
            score_beta_multi_diff_R(pihat.list.b[[o]], mu[task_ind[1:K]], Sigma[task_ind[1:K]])
          })
          pihat.table <- pihat.list.b[[which.min(score.list)]]


          pihat.reordered <- t(sapply(1:K, function(k){
            pihat.table[task_ind == k,]
          }))
          pihat.reordered
        }, simplify = FALSE)
      } else { # not revised
        registerDoParallel(ncores)
        pihat.list <- foreach(b = 1:num_replication) %dopar% {
          # task_ind <- sample(K)
          task_ind <- Reduce(c, lapply(index_by_R, function(x){
            if (length(x) > 1) {
              sample(x)
            } else {
              x
            }
          }))
          pihat.list.b <- sapply(1:R[task_ind[1]], function(o){
            pihat.table <- rep(NA, R_max)
            pihat.table[1:R[task_ind[1]]] <- 1:R[task_ind[1]]
            # change the reference class for the 1st task
            pihat.table[o] <- 1
            pihat.table[1] <- o
            for (k in 2:K) {
              pihat.index0 <- permutations(n = R_max, r = R[task_ind[k]], v = 1:R_max)
              pihat.index.table <- t(sapply(1:nrow(pihat.index0), function(i){
                match(1:R_max, pihat.index0[i, ])
              }))
              pihat.index.table <- pihat.index.table[!is.na(pihat.index.table[, 1]), ]

              mu.cur <- mu[task_ind[1:k]]
              Sigma.cur <- Sigma[task_ind[1:k]]
              score.list <- sapply(1:nrow(pihat.index.table), function(i){
                pihat.table.cur <- rbind(pihat.table, pihat.index.table[i, ])
                score_beta_multi_diff_R(pihat.table.cur, mu.cur, Sigma.cur)
              })
              i0 <- which.min(score.list)
              pihat.table <- rbind(pihat.table, pihat.index.table[i0, ])
            }
            pihat.table
          }, simplify = FALSE)
          # select the optimal order from R[k]
          score.list <- sapply(1:R[task_ind[1]], function(o){
            score_beta_multi_diff_R(pihat.list.b[[o]], mu[task_ind[1:K]], Sigma[task_ind[1:K]])
          })
          pihat.table <- pihat.list.b[[which.min(score.list)]]


          pihat.reordered <- t(sapply(1:K, function(k){
            pihat.table[task_ind == k,]
          }))
          pihat.reordered
        }
        stopImplicitCluster()
      }

    } else {
      stop("When diff_R = TRUE, method has to be 'greedy'!")
    }

  }
  score.list <- sapply(1:num_replication, function(b){
    score_beta_multi_diff_R(pihat.list[[b]], mu, Sigma)
  })
  pihat.table <- pihat.list[[which.min(score.list)]]
  return(pihat.table)


}
