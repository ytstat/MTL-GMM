#' @title Generate data for simulations.
#'
#' @description Generate data for simulations. All models used in Tian, Y. et al. (2022) are implemented.
#' @export
#' @param K the number of tasks (data sets). Default: 10
#' @param outlier_K the number of outlier tasks. Default: 1
#' @param simulation_no simulation number in Tian, Y. et al. (2022). Can be "MTL-1", "MTL-2", "MTL-3", "MTL-epsilon", "MTL-diff-R", and "MTL-repre". Default = "MTL-1".
#' \itemize{
#' \item MTL-1: Simulation 1 of MTL in Tian, Y. et al. (2022).
#' \item MTL-2: Simulation 2 of MTL in Tian, Y. et al. (2022). See Section S.5.1.2 of the supplement.
#' \item MTL-3: Simulation 3 of MTL in Tian, Y. et al. (2022). See Section S.5.1.3 of the supplement.
#' \item MTL-epsilon: Simulation 4 of MTL in Tian, Y. et al. (2022). See Section S.5.1.4 of the supplement.
#' \item MTL-diff-R: Simulation 5 of MTL in Tian, Y. et al. (2022). See Section S.5.1.5 of the supplement.
#' \item MTL-repre: Simulation 6 of MTL in Tian, Y. et al. (2022). See Section S.5.1.5 of the supplement.
#' }
#' @param h the value of h. Default: 1
#' @param n the sample size of each task. Can be either an positive integer or a vector of length \code{K}. If it is an integer, then the sample size of all tasks will be the same and equal to \code{n}. If it is a vector, then the k-th number will be the sample size of the k-th task. Default: 50.
#' @param p the number of features.
#' @param d the number of intrinsic dimension. Only useful when \code{simulation_no} = "MTL-repre". See the simulations in Section S.5.1.5 of the supplement of Tian et al. (2022).
#' @param prob the probability of each cluster in GMMs. Only useful when \code{simulation_no} = "MTL-diff-R". See the simulations in Section S.5.1.5 of the supplement of Tian et al. (2022).
#' @return a list of two sub-lists "data" and "parameter". List "data" contains a list of design matrices \code{x}, a list of hidden labels \code{y}, and a vector of outlier task indices \code{outlier_index}. List "parameter" contains a vector \code{w} of mixture proportions, a matrix \code{mu1} of which each column is the GMM mean of the first cluster of each task, a matrix \code{mu2} of which each column is the GMM mean of the second cluster of each task, a matrix \code{beta} of which each column is the discriminant coefficient in each task, a list \code{Sigma} of covariance matrices for each task.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' @examples
#' data_list <- data_generation(K = 5, outlier_K = 1, simulation_no = "MTL-1",
#' h = 1, n = 50, p = 10)


data_generation <- function(K = 10, outlier_K = 1, simulation_no = c("MTL-1", "MTL-2", "MTL-3", "MTL-epsilon", "MTL-diff-R", "MTL-repre"), h = 1, n = 50, p = 5, d = 5, prob = NULL) {
  outlier_index <- sample(K, size = outlier_K)
  simulation_no <- match.arg(simulation_no)

  if (length(n) == 1) {
    n <- rep(n, K)
  }

  if (simulation_no == "MTL-1") {
    Sigma <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        outer(1:p, 1:p, function(x,y){0.2^(abs(x-y))})
      } else {
        outer(1:p, 1:p, function(x,y){0.5^(abs(x-y))})
      }
    }, simplify = FALSE)

    w <- 0.5+runif(K, min = -0.4, max = 0.4)
    mu1 <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        z <- rnorm(p)
        z <- z/vec_norm(z)
        c(2, 2, rep(0, p-2)) + h/2*Sigma[[k]]%*%z
      } else {
        z <- rnorm(p)
        z <- z/vec_norm(z)
        5*z
      }
    })

    mu2 <- -mu1

    beta <- sapply(1:K, function(k){
      solve(Sigma[[k]]) %*% (mu2[, k] - mu1[, k])
    })

    delta <- sapply(1:K, function(k){
      sum(beta[, k]*(mu2[, k] + mu1[, k])/2)
    })

    y <- sapply(1:K, function(k){
      sample(1:2, size = n[k], replace = TRUE, prob = c(1-w[k], w[k]))
    }, simplify = FALSE)

    x <- sapply(1:K, function(k){
      x <- (1-(y[[k]]-1))*t(t(matrix(rnorm(n[k]*p), ncol = p) %*% chol(Sigma[[k]])) + mu1[, k]) +
        (y[[k]]-1)*t(t(matrix(rnorm(n[k]*p), ncol = p) %*% chol(Sigma[[k]])) + mu2[, k])
      x
    }, simplify = FALSE)

    return(list(data = list(x = x, y = y, outlier_index = outlier_index), parameter = list(w = w, mu1 = mu1, mu2 = mu2, beta = beta, delta = delta, Sigma = Sigma, R = 2)))

  } else if (simulation_no == "MTL-2") {
    R <- 4
    w <- t(rdirichlet(K, alpha = rep(5, R)))

    Sigma <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        outer(1:p, 1:p, function(x,y){0.2^(abs(x-y))})
      } else {
        outer(1:p, 1:p, function(x,y){0.5^(abs(x-y))})
      }
    }, simplify = FALSE)

    mu <- rep(list(matrix(nrow = p, ncol = K)), R)

    mu[[1]] <- matrix(0, nrow = p, ncol = K)
    for (r in 2:R) {
      mu[[r]] <- sapply(1:K, function(k){
        z <- rnorm(p)
        z <- z/vec_norm(z)
        c(rep(0, 2*(r-2)), 2, 2, rep(0, p-2*(r-1)))*1.5 + h/2*Sigma[[k]]%*%z
      })

      for (k in outlier_index) {
        z <- rnorm(p)
        z <- z/vec_norm(z)
        mu[[r]][, k] <- 5*z
      }
    }


    beta <- sapply(1:R, function(r){
      if(r == 0){
        matrix(0, nrow = p, ncol = K)
      } else {
        sapply(1:K, function(k){
          solve(Sigma[[k]]) %*% (mu[[r]][, k] - mu[[1]][, k])
        })
      }
    }, simplify = FALSE)

    delta <- sapply(1:R, function(r){
      if (r == 1) {
        numeric(K)
      } else {
        sapply(1:K, function(k){
          sum(beta[[r]][, k]*(mu[[r]][, k] + mu[[r]][, 1])/2)
        })
      }
    })

    y <- sapply(1:K, function(k){
      sample(1:R, size = n[k], replace = TRUE, prob = w[, k])
    }, simplify = FALSE)

    x <- sapply(1:K, function(k){
      t(sapply(1:n[k], function(i){
        chol(Sigma[[k]]) %*% rnorm(p) + mu[[y[[k]][i]]][, k]
      }))
    }, simplify = FALSE)
    return(list(data = list(x = x, y = y, outlier_index = outlier_index), parameter = list(w = w, mu = mu, beta = beta, delta = delta, Sigma = Sigma, R = R)))
  } else if (simulation_no == "MTL-3") {
    outlier_index <- sample(2:K, size = outlier_K)
    w <- 0.5+runif(K, min = -0.4, max = 0.4)
    R <- 2

    Sigma <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        if (k == 1){
          outer(1:5, 1:5, function(x,y){0.5^(abs(x-y))})
        } else {
          rv <- sample(0:1, size = 1)
          if (rv == 0) {
            outer(1:5, 1:5, function(x,y){0.5^(abs(x-y))})
          } else {
            hcomp <- function(epsilon) {
              Sigma0 <- outer(1:5, 1:5, function(x,y){0.5^(abs(x-y))})
              Sigma1 <- outer(1:5, 1:5, function(x,y){epsilon^(abs(x-y))})
              Delta <- as.numeric(solve(Sigma1) %*% (Sigma0 - Sigma1) %*% c(4,0,0,0,0))
              vec_norm(Delta)-h
            }

            outer(1:5, 1:5, function(x,y){(uniroot(hcomp, interval=c(0.5,0.999))$root)^(abs(x-y))})
          }
        }
      } else {
        outer(1:5, 1:5, function(x,y){0.5^(abs(x-y))})
      }
    }, simplify = FALSE)


    beta <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        if (k == 1) {
          c(4,0,0,0,0)
        } else {
          Delta <- as.numeric(solve(Sigma[[k]]) %*% (Sigma[[1]] - Sigma[[k]]) %*% c(4,0,0,0,0))
          c(4,0,0,0,0) + Delta
        }
      } else {
        z <- rnorm(5)
        z <- z/vec_norm(z)
        c(-4,-4,-4,-4,-4)
      }
    })


    mu1 <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        -Sigma[[k]]%*%beta[, k]
      } else {
        -Sigma[[k]]%*%beta[, k]/2
      }
    })

    # mu2 <- -mu1
    mu2 <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        numeric(5)
      } else {
        Sigma[[k]]%*%beta[, k]/2
      }
    })

    delta <- sapply(1:K, function(k){
      sum(beta[, k]*(mu2[, k] + mu1[, k])/2)
    })


    y <- sapply(1:K, function(k){
      sample(1:2, size = n[k], replace = TRUE, prob = c(1-w[k], w[k]))
    }, simplify = FALSE)

    x <- sapply(1:K, function(k){
      x <- (1-(y[[k]]-1))*t(t(matrix(rnorm(n[k]*5), ncol = 5) %*% chol(Sigma[[k]])) + mu1[, k]) +
        (y[[k]]-1)*t(t(matrix(rnorm(n[k]*5), ncol = 5) %*% chol(Sigma[[k]])) + mu2[, k])
      if (!(k %in% outlier_index)) {
        x
      } else {
        (1-(y[[k]]-1))*t(t(matrix(rnorm(n[k]*5), ncol = 5) %*% chol(Sigma[[k]])) + mu1[, k]) + (y[[k]]-1)*matrix(rt(n[k]*5, df = 4), ncol = 5)
      }
    }, simplify = FALSE)
    return(list(data = list(x = x, y = y, outlier_index = outlier_index), parameter = list(w = w, mu1 = mu1, mu2 = mu2, beta = beta, delta = delta, Sigma = Sigma, R = R)))

  } else if (simulation_no == "MTL-epsilon") {
    w <- 0.5+runif(K, min = -0.4, max = 0.4)
    R <- 2
    Sigma <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        outer(1:p, 1:p, function(x,y){0.2^(abs(x-y))})
      } else {
        outer(1:p, 1:p, function(x,y){0.5^(abs(x-y))})
      }
    }, simplify = FALSE)

    mu1 <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        z <- rnorm(p)
        z <- z/vec_norm(z)
        rep(1, p)/sqrt(p)*2 + h/2*Sigma[[k]]%*%z
      } else {
        z <- rnorm(p)
        z <- z/vec_norm(z)
        10*z
      }
    })

    mu2 <- -mu1

    beta <- sapply(1:K, function(k){
      solve(Sigma[[k]]) %*% (mu2[, k] - mu1[, k])
    })

    delta <- sapply(1:K, function(k){
      sum(beta[, k]*(mu2[, k] + mu1[, k])/2)
    })

    y <- sapply(1:K, function(k){
      sample(1:2, size = n[k], replace = TRUE, prob = c(1-w[k], w[k]))
    }, simplify = FALSE)


    x <- sapply(1:K, function(k){
      x <- (1-(y[[k]]-1))*t(t(matrix(rnorm(n[k]*p), ncol = p) %*% chol(Sigma[[k]])) + mu1[, k]) +
        (y[[k]]-1)*t(t(matrix(rnorm(n[k]*p), ncol = p) %*% chol(Sigma[[k]])) + mu2[, k])
      x
    }, simplify = FALSE)
    return(list(data = list(x = x, y = y, outlier_index = outlier_index), parameter = list(w = w, mu1 = mu1, mu2 = mu2, beta = beta, delta = delta, Sigma = Sigma, R = R)))

  } else if (simulation_no == "MTL-diff-R") {
    Sigma <- sapply(1:K, function(k){
      if (!(k %in% outlier_index)) {
        outer(1:p, 1:p, function(x,y){0.2^(abs(x-y))})
      } else {
        outer(1:p, 1:p, function(x,y){0.5^(abs(x-y))})
      }
    }, simplify = FALSE)

    R <- sample(2:4, size = K, replace = T)

    w <- sapply(1:K, function(k){
      t(rdirichlet(1, alpha = rep(5, R[k])))
    }, simplify = F)


    mu <- sapply(1:K, function(k){
      matrix(0, nrow = p, ncol = R[k])
    }, simplify = F)


    for (k in 1:K) {
      mu[[k]][, 2:R[k]] <- sapply(2:R[k], function(r){
        z <- rnorm(p)
        z <- z/vec_norm(z)
        c(rep(0, 2*(r-2)), 2, 2, rep(0, p-2*(r-1)))*1.5 + h/2*Sigma[[k]]%*%z
      })
    }

    beta <- sapply(1:K, function(k){
      sapply(1:R[k], function(r){
        solve(Sigma[[k]]) %*% (mu[[k]][, r] - mu[[k]][, 1])
      })
    }, simplify = FALSE)

    delta <- sapply(1:K, function(k){
      sapply(1:R[k], function(r){
        sum(beta[[k]][, r]*(mu[[k]][, r] + mu[[k]][, 1])/2)
      })
    }, simplify = FALSE)

    y <- sapply(1:K, function(k){
      sample(1:R[k], size = n[k], replace = TRUE, prob = w[[k]])
    }, simplify = FALSE)

    x <- sapply(1:K, function(k){
      t(sapply(1:n[k], function(i){
        chol(Sigma[[k]]) %*% rnorm(p) + mu[[k]][, y[[k]][i]]
      }))
    }, simplify = FALSE)
    return(list(data = list(x = x, y = y, outlier_index = outlier_index), parameter = list(w = w, mu = mu, beta = beta, delta = delta, Sigma = Sigma, R = R)))

  } else if (simulation_no == "MTL-repre") {
    outlier_index <- integer(0)
    A <- svd(matrix(rnorm(p*p), nrow = p))$u[,1:d]

    R <- sample(2:5, size = K, replace = T)

    w <- sapply(1:K, function(k){
      t(rdirichlet(1, alpha = rep(5, R[k])))
    }, simplify = F)

    Sigma <- sapply(1:K, function(k){outer(1:p, 1:p, function(x,y){0.2^(abs(x-y))})}, simplify = F)

    mu <- sapply(1:K, function(k){
      matrix(nrow = p, ncol = R[k])
    }, simplify = F)

    for (k in 1:K) {
      mu[[k]] <- sapply(1:R[k], function(r){
        z <- rnorm(d)
        z <- 3*z/vec_norm(z)
        A %*% z
      })
    }

    beta <- sapply(1:K, function(k){
      sapply(1:R[k], function(r){
        solve(Sigma[[k]]) %*% (mu[[k]][, r] - mu[[k]][, 1])
      })
    }, simplify = FALSE)

    delta <- sapply(1:K, function(k){
      sapply(1:R[k], function(r){
        sum(beta[[k]][, r]*(mu[[k]][, r] + mu[[k]][, 1])/2)
      })
    }, simplify = FALSE)

    y <- sapply(1:K, function(k){
      sample(1:R[k], size = n[k], replace = TRUE, prob = w[[k]])
    }, simplify = FALSE)

    x <- sapply(1:K, function(k){
      t(sapply(1:n[k], function(i){
        chol(Sigma[[k]]) %*% rnorm(p) + mu[[k]][, y[[k]][i]]
      }))
    }, simplify = FALSE)

    return(list(data = list(x = x, y = y, outlier_index = outlier_index), parameter = list(w = w, mu = mu, beta = beta, delta = delta, Sigma = Sigma, R = R)))

  }


}
