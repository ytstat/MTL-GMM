#' @title Fit binary Gaussian mixture models (GMMs) on multiple data sets under a multi-task learning (MTL) setting.
#'
#' @description It fits binary Gaussian mixture models (GMMs) on multiple data sets under a multi-task learning (MTL) setting. This function implements the modified EM algorithm (Altorithm 1) proposed in Tian, Y. et al. (2022).
#' @export
#' @importFrom foreach foreach %do% %dopar%
#' @importFrom doParallel registerDoParallel stopImplicitCluster
#' @importFrom mclust dmvnorm Mclust mclustBIC
#' @importFrom stats runif rnorm kmeans rt uniroot quantile dist median sd
#' @importFrom utils capture.output
#' @importFrom caret createFolds
#' @importFrom DirichletReg rdirichlet
#' @importFrom gtools permutations
#' @importFrom igraph graph_from_adjacency_matrix components
#' @param x design matrices from multiple data sets. Should be a list, of which each component is a \code{matrix} or \code{data.frame} object, representing the design matrix from each task.
#' @param step_size step size choice in proximal gradient method to solve each optimization problem in the revised EM algorithm (Algorithm 1 in Tian, Y. et al. (2022)), which can be either "lipschitz" or "fixed". Default = "lipschitz".
#' \itemize{
#' \item lipschitz: \code{eta_beta} will be chosen by the Lipschitz property of the gradient of objective function (without the penalty part). See Section 4.2 of Parikh, N., & Boyd, S. (2014).
#' \item fixed: \code{eta_beta} need to be specified
#' }
#' @param eta_beta step size in the proximal gradient method to learn beta (Step 9 of Algorithm 1 in Tian, Y. et al. (2022)). Default: 0.1. Only used when \code{step_size} = "fixed".
#' @param lambda_choice the choice of constants in the penalty parameter used in the optimization problems. See Algorithm 1 of Tian, Y. et al. (2022), which can be either "fixed" or "cv". Default: "cv".
#' \itemize{
#' \item cv: \code{cv_nfolds}, \code{cv_upper}, and \code{cv_length} need to be specified. Then \code{C_lambda} will be chosen in all combinations in \code{exp(seq(log(cv_lower/10), log(cv_upper/10), length.out = cv_length))} via cross-validation.
#' \item fixed: \code{C_lambda} need to be specified. See equations (7)-(12) in Tian, Y. et al. (2022).
#' }
#' @param cv_nfolds the number of cross-validation folds. Default: 10
#' @param cv_upper the upper bound of \code{lambda} values used in cross-validation. Default: 10
#' @param cv_lower the lower bound of \code{lambda} values used in cross-validation. Default: 0.01
#' @param cv_length the number of \code{lambda} values considered in cross-validation. Default: 10
#' @param C_lambda the initial value of C_lambda in Step 3 of Algorithm 1 in Tian, Y. et al. (2022). Default: 1
#' @param kappa the decaying rate used in Step 3 of Algorithm 1 in Tian, Y. et al. (2022). Default: 1/3
#' @param tol maximum tolerance in all optimization problems. If the difference between last update and the current update is less than this value, the iterations of optimization will stop. Default: 1e-05
#' @param initial_method initialization method. This indicates the method to initialize the estimates of GMM parameters for each data set. Can be either "EM" or "kmeans". Default: "EM".
#' \itemize{
#' \item EM: the initial estimates of GMM parameters will be generated from the single-task EM algorithm. Will call \code{\link[mclust]{Mclust}} function in \code{mclust} package.
#' \item kmeans: the initial estimates of GMM parameters will be generated from the single-task k-means algorithm. Will call \code{\link[stats]{kmeans}} function in \code{stats} package.
#' }
#' @param alignment_method the alignment algorithm to use. See Section 2.4 of Tian, Y. et al. (2022). Can either be "exhaustive" or "greedy". Default: when \code{length(x)} <= 10, "exhaustive" will be used, otherwise "greedy" will be used.
#' \itemize{
#' \item exhaustive: exhaustive search algorithm (Algorithm 2 in Tian, Y. et al. (2022)) will be used.
#' \item greedy: greedy label swapping algorithm (Algorithm 3 in Tian, Y. et al. (2022)) will be used.
#' }
#' @param trim the proportion of trimmed datasets among all datasets (the same proportion from both bottom and top) in the cross-validation procedure of choosing tuning parameters. Setting it to a non-zero small value can help avoid the impact of outlier tasks on the choice of tuning parameters. Default: 0.1
#' @param iter_max the maximum iteration number of the revised EM algorithm (i.e. the parameter T in Algorithm 1 in Tian, Y. et al. (2022)). Default: 1000
#' @param iter_max_prox the maximum iteration number of the proximal gradient method. Default: 100
#' @param ncores the number of cores to use. Parallel computing is strongly suggested, specially when \code{lambda_choice} = "cv". Default: 1
#' @param cv_criterion the way used in cross-validation to aggregate the loss function from different tasks. Can be either "trimmed_mean" or "median". Default: "trimmed_mean". The trimming proportion is indicated by the parameter \code{trim}.
#' @param num_replication the number of random replications in the greedy alignment method. The final alignment will be chosen as the best result among these replications. Only used when \code{initial_method} = "greedy". See Remark 5 of Tian, Y. et al. (2022). Default = 50.
#' @return A list with the following components.
#' \item{w}{the estimate of mixture proportion in GMMs for each task. Will be a vector.}
#' \item{mu1}{the estimate of Gaussian mean in the first cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{mu2}{the estimate of Gaussian mean in the second cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{beta}{the estimate of the discriminant coefficient for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{Sigma}{the estimate of the common covariance matrix for each task. Will be a list, where each component represents the estimate for a task.}
#' \item{beta_bar}{the center estimate of beta. Will be a vector. See Algorithm 1 in Tian, Y. et al. (2022).}
#' \item{initial_beta}{the well-aligned initial estimate of beta of different tasks. Useful for the alignment problem in transfer learning. See Section 2.4 in Tian, Y. et al. (2022).}
#' \item{C_lambda}{the C_lambda value used in the algorithm}
#' \item{C_lambda.list}{the list of C_lambda candidate values used in cross-validation when \code{lambda_choice} = "cv".}
#' @seealso \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' Parikh, N., & Boyd, S. (2014). Proximal algorithms. Foundations and trends in Optimization, 1(3), 127-239.
#'
#' @examples
#' \donttest{
#' # use cross-validation to choose the tuning parameters
#' # warning: can be quite slow, large "ncores" input is suggested!!
#' set.seed(23, kind = "L'Ecuyer-CMRG")
#' library(mclust)
## Consider a 5-task multi-task learning problem in the setting "MTL-1"
#' K <- 5
#' # generate data
#' data_list <- data_generation(K = K, outlier_K = 1, simulation_no = "MTL-1", p = 10,
#'                              h = 1, n = 150)  # generate the data
#' x_train <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][1:50,]
#' }, simplify = FALSE)
#' x_test <- sapply(1:K, function(k){
#'   data_list$data$x[[k]][-(1:50),]
#' }, simplify = FALSE)
#' y_test <- sapply(1:K, function(k){
#'   data_list$data$y[[k]][-(1:50)]
#' }, simplify = FALSE)
#'
#' # fit MTL-GMM
#' fit <- mtlgmm(x = x_train, cv_nfolds = 5, initial_method = "EM", lambda_choice = "cv",
#'               ncores = 2, trim = 1/K)
#'
#' # compare the performance with that of single-task estimators
#' # fit single-task GMMs
#' fitted_values <- initialize(x_train, "EM")  # initilize the estimates
#' r <- alignment(fitted_values$beta, method = "exhaustive")  # call the alignment algorithm
#' fitted_values <- alignment_swap(r, fitted_values)  # obtain the well-aligned initial estimates
#'# fit a pooled GMM
#' x.comb <- Reduce("rbind", x_train)
#' fit_pooled <- Mclust(x.comb, G = 2, modelNames = "EEE")
#' fitted_values_pooled <- list(w = NULL, mu1 = NULL, mu2 = NULL, beta = NULL,
#' Sigma = NULL, delta = NULL)
#' fitted_values_pooled$w <- rep(fit_pooled$parameters$pro[2], K)
#' fitted_values_pooled$mu1 <- matrix(rep(fit_pooled$parameters$mean[,1], K), ncol = K)
#' fitted_values_pooled$mu2 <- matrix(rep(fit_pooled$parameters$mean[,2], K), ncol = K)
#' fitted_values_pooled$Sigma <- sapply(1:K, function(k){
#'   fit_pooled$parameters$variance$Sigma
#' }, simplify = FALSE)
#' fitted_values_pooled$beta <- sapply(1:K, function(k){
#'   solve(fit_pooled$parameters$variance$Sigma) %*%
#'   (fit_pooled$parameters$mean[,2] - fit_pooled$parameters$mean[,1])
#' })
#' fitted_values_pooled$delta <- sapply(1:K, function(k){
#'   sum(fitted_values_pooled$beta[, k]*
#'   (fitted_values_pooled$mu1[, k] + fitted_values_pooled$mu2[, k])/2)
#' })
#' error <- matrix(nrow = 3, ncol = 5,
#' dimnames = list(c("Single-task-GMM","Pooled-GMM","MTL-GMM"),
#'                 c("w", "mu", "beta", "Sigma", "Misclustering_error")))
#' error["Single-task-GMM", "w"] <- estimation_error(
#'   fitted_values$w[-data_list$data$outlier_index],
#'   data_list$parameter$w[-data_list$data$outlier_index], "w")
#' error["Pooled-GMM", "w"] <- estimation_error(
#'   fitted_values_pooled$w[-data_list$data$outlier_index],
#'   data_list$parameter$w[-data_list$data$outlier_index], "w")
#' error["MTL-GMM", "w"] <- estimation_error(
#'   fit$w[-data_list$data$outlier_index],
#'   data_list$parameter$w[-data_list$data$outlier_index], "w")
#'
#' error["Single-task-GMM", "mu"] <- estimation_error(
#'   list(fitted_values$mu1[, -data_list$data$outlier_index],
#'        fitted_values$mu2[, -data_list$data$outlier_index]),
#'   list(data_list$parameter$mu1[, -data_list$data$outlier_index],
#'        data_list$parameter$mu2[, -data_list$data$outlier_index]), "mu")
#' error["Pooled-GMM", "mu"] <- estimation_error(list(
#'   fitted_values_pooled$mu1[, -data_list$data$outlier_index],
#'   fitted_values_pooled$mu2[, -data_list$data$outlier_index]),
#'  list(data_list$parameter$mu1[, -data_list$data$outlier_index],
#'        data_list$parameter$mu2[, -data_list$data$outlier_index]), "mu")
#' error["MTL-GMM", "mu"] <- estimation_error(list(
#'   fit$mu1[, -data_list$data$outlier_index],
#'   fit$mu2[, -data_list$data$outlier_index]),
#'   list(data_list$parameter$mu1[, -data_list$data$outlier_index],
#'        data_list$parameter$mu2[, -data_list$data$outlier_index]), "mu")
#'
#' error["Single-task-GMM", "beta"]  <- estimation_error(
#'   fitted_values$beta[, -data_list$data$outlier_index],
#'   data_list$parameter$beta[, -data_list$data$outlier_index], "beta")
#' error["Pooled-GMM", "beta"] <- estimation_error(
#'   fitted_values_pooled$beta[, -data_list$data$outlier_index],
#'   data_list$parameter$beta[, -data_list$data$outlier_index], "beta")
#' error["MTL-GMM", "beta"] <- estimation_error(
#'   fit$beta[, -data_list$data$outlier_index],
#'   data_list$parameter$beta[, -data_list$data$outlier_index], "beta")
#'
#' error["Single-task-GMM", "Sigma"] <- estimation_error(
#'   fitted_values$Sigma[-data_list$data$outlier_index],
#'   data_list$parameter$Sigma[-data_list$data$outlier_index], "Sigma")
#' error["Pooled-GMM", "Sigma"] <- estimation_error(
#'   fitted_values_pooled$Sigma[-data_list$data$outlier_index],
#'   data_list$parameter$Sigma[-data_list$data$outlier_index], "Sigma")
#' error["MTL-GMM", "Sigma"] <- estimation_error(
#'   fit$Sigma[-data_list$data$outlier_index],
#'   data_list$parameter$Sigma[-data_list$data$outlier_index], "Sigma")
#'
#' # prediction on the test data
#' y_pred_single <- sapply(1:K, function(k){
#'   predict_gmm(w = fitted_values$w[k], mu1 = fitted_values$mu1[, k],
#'   mu2 = fitted_values$mu2[, k], beta = fitted_values$beta[, k], newx = x_test[[k]])
#' }, simplify = FALSE)
#' y_pred_pooling <- sapply(1:K, function(k){
#'   predict_gmm(w = fitted_values_pooled$w[k], mu1 = fitted_values_pooled$mu1[, k],
#'   mu2 = fitted_values_pooled$mu2[, k], beta = fitted_values_pooled$beta[, k], newx = x_test[[k]])
#' }, simplify = FALSE)
#' y_pred_mtlgmm <- sapply(1:K, function(k){
#'   predict_gmm(w = fit$w[k], mu1 = fit$mu1[, k], mu2 = fit$mu2[, k], beta = fit$beta[, k],
#'   newx = x_test[[k]])
#' }, simplify = FALSE)
#'
#' error["Single-task-GMM", "Misclustering_error"] <-
#' misclustering_error(y_pred_single[-data_list$data$outlier_index],
#'                     y_test[-data_list$data$outlier_index], "max")
#' error["Pooled-GMM", "Misclustering_error"] <-
#' misclustering_error(y_pred_pooling[-data_list$data$outlier_index],
#'                     y_test[-data_list$data$outlier_index], "max")
#' error["MTL-GMM", "Misclustering_error"] <-
#' misclustering_error(y_pred_mtlgmm[-data_list$data$outlier_index],
#'                     y_test[-data_list$data$outlier_index], "max")
#'
#' # print the maximum estimation error and maximum prediction
#' # mis-clustering error (for non-outlier tasks)
#' print(error)
#' }
#'

mtlgmm <- function(x, step_size = c( "lipschitz", "fixed"), eta_beta = 0.1,
                   lambda_choice = c("cv", "fixed"), cv_nfolds = 10, cv_upper = 10, cv_lower = 0.01, cv_length = 10, C_lambda=1,
                   kappa = 1/3, tol = 1e-5, initial_method = c("EM", "kmeans"), alignment_method = ifelse(length(x) <= 10, "exhaustive", "greedy"),
                   trim = 0.1, iter_max = 1000, iter_max_prox = 100, ncores = 1, cv_criterion = c("trimmed_mean", "median"),
                   num_replication = 50) {

  lambda_choice <- match.arg(lambda_choice)
  step_size <- match.arg(step_size)
  initial_method <- match.arg(initial_method)
  cv_criterion <- match.arg(cv_criterion)

  # basic parameters
  p <- ncol(x[[1]])
  K <- length(x)
  n <- sapply(1:K, function(k){nrow(x[[k]])})


  i <- NULL # just to avoid the error message "no visible binding for global variable 'i'"

  registerDoParallel(ncores)

  # initialization and alignment adjustment
  # ---------------------------------------------
  fitted_values <- initialize(x, initial_method)
  if (alignment_method == "exhaustive") {
    r <- alignment(fitted_values$beta, method = "exhaustive")
  } else if (alignment_method == "greedy") {
    r <- alignment(fitted_values$beta, method = "greedy", num_replication, ncores)
  }
  fitted_values <- alignment_swap(r, initial_value_list = fitted_values)

  # MTL-EM
  # -------------------------
  w <- fitted_values$w
  mu1 <- fitted_values$mu1
  mu2 <- fitted_values$mu2
  beta <- fitted_values$beta
  Sigma <- fitted_values$Sigma


  Sigma_avg <- Reduce("+", sapply(1:K, function(k){
    n[k]*Sigma[[k]]
  }, simplify = FALSE))
  mu_diff_avg <- rowSums(t(n*t(mu2-mu1)))
  beta_avg <- solve(Sigma_avg) %*% mu_diff_avg

  lambda_max <- max(sapply(1:K, function(k){
    sqrt(n[k])*vec_norm(Sigma[[k]] %*% beta_avg - (mu2[, k] - mu1[, k]))
  }))

  if (lambda_choice != "cv") {
    C_lambda.list <- C_lambda
  }

  if (lambda_choice == "cv") {
    folds_index <- sapply(1:K, function(k){
      createFolds(1:n[k], k = cv_nfolds, list = TRUE)
    }, simplify = FALSE)


    if (cv_upper != "auto") {
      C_lambda.list <- exp(seq(log(cv_lower), log(cv_upper), length.out = cv_length))
    } else {
      C_lambda_up <- 1000
      C_lambda_low <- 0
      while(1) {
        C_lambda <- (C_lambda_up + C_lambda_low)/2
        beta_cur <- beta_fit(C_lambda, x, n, w, mu1, mu2, beta, Sigma, p, K, tol, kappa, iter_max, iter_max_prox, step_size)

        D <- as.matrix(dist(t(beta_cur)))
        eps <- 1e-2    # your tolerance
        Adj  <- (D <= eps)   # logical adjacency
        diag(Adj) <- FALSE
        g <- graph_from_adjacency_matrix(Adj, mode="undirected")
        comps <- components(g)$csize
        max_cluster_size <- max(comps)
        if (max_cluster_size >= K*(1-2*trim)) {
          C_lambda_up <- C_lambda
        } else {
          C_lambda_low <- C_lambda
        }


        if(abs(C_lambda_up - C_lambda_low)<=1) {
          C_lambda <- C_lambda_up
          break
        }
      }
      if (trim <= 0.25) {
        C_lambda.list <- exp(seq(log(C_lambda/100*2), log(C_lambda*2), length.out = cv_length))
      } else { # expect large proportion of outliers -> lower down the lambda choices
        C_lambda.list <- exp(seq(log(C_lambda/100), log(C_lambda), length.out = cv_length))
      }
    }


    emp_logL <- foreach(i = 1:length(C_lambda.list), .combine = "rbind") %dopar% {
      sapply(1:cv_nfolds, function(j){
        x.train <- sapply(1:K, function(k){
          x[[k]][-folds_index[[k]][[j]], ]
        }, simplify = FALSE)

        # prevent singularity
        for (k in 1:K) {
          for (v in 1:p) {
            if (sd(x.train[[k]][, v]) <= 1e-2 || length(unique(x.train[[k]][, v])) <= 3) {
              x.train[[k]][, v] <- x.train[[k]][, v] + rnorm(nrow(x.train[[k]]), sd = 1e-2)
            }
          }
        }

        x.valid <- sapply(1:K, function(k){
          x[[k]][folds_index[[k]][[j]], ]
        }, simplify = FALSE)

        n.train <- sapply(1:K, function(k){nrow(x.train[[k]])})
        lambda.t <- C_lambda.list[i]*sqrt(max(n.train))

        for (l in 1:iter_max) {
          lambda.t <- kappa*lambda.t + C_lambda.list[i]*sqrt(p+log(K))

          gamma <- sapply(1:K, function(k){
            as.numeric(w[k]/(w[k] + (1-w[k])*exp(-t(beta[, k]) %*% (t(x.train[[k]]) - (mu1[, k] + mu2[, k])/2))))
          }, simplify = FALSE)


          # w
          w.old <- w
          w <- sapply(1:K, function(k){
            a <- mean(gamma[[k]])
            a[a <= 1e-7] <- 1e-7
            a[1-a <= 1e-7] <- 1-1e-7
            a
          })

          # mu1 and mu2
          mu1.old <- mu1
          mu1 <- sapply(1:K, function(k){
            colMeans((1-gamma[[k]])*x.train[[k]])/(1-w[k])
          })

          mu2.old <- mu2
          mu2 <- sapply(1:K, function(k){
            colMeans(gamma[[k]]*x.train[[k]])/w[k]
          })

          # Sigma
          Sigma.old <- Sigma
          Sigma <- sapply(1:K, function(k){
            Sigma1 <- t(x.train[[k]] - matrix(rep(mu1[, k], n.train[k]), nrow =  n.train[k], byrow = T)) %*% diag(1-as.numeric(gamma[[k]])) %*% (x.train[[k]] - matrix(rep(mu1[, k], n.train[k]), nrow = n.train[k], byrow = T))
            Sigma2 <- t(x.train[[k]] - matrix(rep(mu2[, k], n.train[k]), nrow =  n.train[k], byrow = T)) %*% diag(as.numeric(gamma[[k]])) %*% (x.train[[k]] - matrix(rep(mu2[, k], n.train[k]), nrow = n.train[k], byrow = T))
            (Sigma1+Sigma2)/n.train[k]
          }, simplify = FALSE)


          # beta
          if (l == 1) {
            beta.bar <- rowMeans(beta)
            beta.t <- beta - beta.bar
          }
          beta.bar.old.last.round <- beta.bar

          if (step_size == "lipschitz") {
            eta_beta.list <- sapply(1:K, function(k){
              1/(2*norm(Sigma[[k]], "2"))
            })
          } else if (step_size == "fixed") {
            eta_beta.list <- rep(eta_beta, K)
          }

          for (r in 1:iter_max_prox) {
            beta.t.old <- beta.t
            beta.t <- sapply(1:K, function(k){
              eta_beta <- eta_beta.list[k]
              del <- beta.t[, k] - eta_beta*(Sigma[[k]] %*% (beta.t[, k] + beta.bar) + mu1[, k] - mu2[, k])
              max(1-(eta_beta*lambda.t/sqrt(n.train[k]))/sqrt(sum(del^2)), 0)*del
            })

            Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
              n.train[k]*Sigma[[k]]
            }, simplify = FALSE))

            vector.weighted.sum <- rowSums(sapply(1:K, function(k){
              n.train[k]*(-Sigma[[k]]%*%beta.t[, k] - mu1[, k] + mu2[, k])
            }))


            beta.bar.old <- beta.bar
            beta.bar <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

            if (max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)) <= tol) {
              break
            }

          }

          beta.old <- beta
          beta <- beta.t + as.numeric(beta.bar)

          # check whether to terminate the interation process or not
          error <- max(vec_max_norm(w-w.old), col_norm(mu1 - mu1.old), col_norm(mu2 - mu2.old), col_norm(beta - beta.old),
                       max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")})),
                       vec_norm(beta.bar - beta.bar.old.last.round))
          if (error <= tol) {
            break
          }
        }

        loss <- sort(sapply(1:K, function(k){
          sum(log((1-w[k])*dmvnorm(data = x.valid[[k]], mean = mu1[, k], sigma = Sigma[[k]]) +
                    w[k]*dmvnorm(data = x.valid[[k]], mean = mu2[, k], sigma = Sigma[[k]])))
        }), decreasing = FALSE)

        trim_ind <- quantile(1:K, c(trim, 1-trim), type = 1)
        if (cv_criterion == "trimmed_mean") {
          sum(loss[-c(1:floor(trim_ind[1]), ceiling(trim_ind[2]+1):K)])
        } else if (cv_criterion == "median") {
          median(loss)
        }
      })
    }

    C_lambda <- C_lambda.list[which.max(rowMeans(emp_logL))]
    lambda_choice <- "fixed" # run the algorithm again with optimal choice of parameters
  }

  if (lambda_choice == "fixed") {
    lambda.t <- C_lambda*sqrt(max(n))

    for (l in 1:iter_max) {
      lambda.t <- kappa*lambda.t + C_lambda*sqrt(p+log(K))

      gamma <- sapply(1:K, function(k){
        as.numeric(w[k]/(w[k] + (1-w[k])*exp(-t(beta[, k]) %*% (t(x[[k]]) - (mu1[, k] + mu2[, k])/2))))
      }, simplify = FALSE)

      # w
      w.old <- w
      w <- sapply(1:K, function(k){
        a <- mean(gamma[[k]])
        a[a <= 1e-7] <- 1e-7
        a[1-a <= 1e-7] <- 1-1e-7
        a
      })

      # mu1 and mu2
      mu1.old <- mu1
      mu1 <- sapply(1:K, function(k){
        colMeans((1-gamma[[k]])*x[[k]])/(1-w[k])
      })

      mu2.old <- mu2
      mu2 <- sapply(1:K, function(k){
        colMeans(gamma[[k]]*x[[k]])/w[k]
      })


      # Sigma
      Sigma.old <- Sigma
      Sigma <- sapply(1:K, function(k){
        Sigma1 <- t(x[[k]] - matrix(rep(mu1[, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(1-as.numeric(gamma[[k]])) %*% (x[[k]] - matrix(rep(mu1[, k], n[k]), nrow = n[k], byrow = T))
        Sigma2 <- t(x[[k]] - matrix(rep(mu2[, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]])) %*% (x[[k]] - matrix(rep(mu2[, k], n[k]), nrow = n[k], byrow = T))
        (Sigma1+Sigma2)/n[k]
      }, simplify = FALSE)


      # beta
      if (l == 1) {
        beta.bar <- rowMeans(beta)
        beta.t <- beta - beta.bar
      }
      beta.bar.old.last.round <- beta.bar

      eta_beta.list <- sapply(1:K, function(k){
        1/(2*norm(Sigma[[k]], "2"))   # 1/(3*norm(Sigma[[k]], "2"))?
      })
      for (r in 1:iter_max_prox) {
        beta.t.old <- beta.t
        beta.t <- sapply(1:K, function(k){
          eta_beta <- eta_beta.list[k]
          del <- beta.t[, k] - eta_beta*(Sigma[[k]] %*% (beta.t[, k] + beta.bar) + mu1[, k] - mu2[, k])
          max(1-(eta_beta*lambda.t/sqrt(n[k]))/sqrt(sum(del^2)), 0)*del
        })

        Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
          n[k]*Sigma[[k]]
        }, simplify = FALSE))

        vector.weighted.sum <- rowSums(sapply(1:K, function(k){
          n[k]*(-Sigma[[k]]%*%beta.t[, k] - mu1[, k] + mu2[, k])
        }))


        beta.bar.old <- beta.bar
        beta.bar <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

        if (max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)) <= tol) {
          break
        }
      }

      beta.old <- beta
      beta <- beta.t + as.numeric(beta.bar)

      # check whether to terminate the interation process or not
      error <- max(vec_max_norm(w-w.old), col_norm(mu1 - mu1.old), col_norm(mu2 - mu2.old), col_norm(beta - beta.old),
                   max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")})), vec_norm(beta.bar - beta.bar.old.last.round))

      if (error <= tol) {
        break
      }
    }
  }

  stopImplicitCluster()

  delta <- sapply(1:K, function(k){
    sum(beta[, k]*(mu1[, k] + mu2[, k])/2)
  })

  return(list(w = w, mu1 = mu1, mu2 = mu2, beta = beta, delta = delta, Sigma = Sigma, beta_bar = beta.bar,
              initial_beta = fitted_values$beta, C_lambda = C_lambda, C_lambda.list = C_lambda.list))


}
