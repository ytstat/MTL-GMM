vec_norm <- function(x) {
  sqrt(sum(x^2, na.rm = T))
}

col_norm <- function(x) {
  max(sapply(1:ncol(x), function(k){
    vec_norm(x[, k])
  }))
}


vec_max_norm <- function(x) {
  max(abs(x), na.rm = T)
}

norm_vec <- function(x) {
  sqrt(sum(x^2, na.rm = T))
}



safe_dmvnorm <- function(data, mean = NULL, sigma = NULL, log = FALSE, ...) {
  # If mean was left at default mvtnorm will build it inside,
  # otherwise check for missing values:
  if (!is.null(mean) && anyNA(mean)) {
    # return the right length of NA_real_
    n <- if (is.matrix(data)) nrow(data) else length(data)
    return(rep(NA_real_, n))
  }
  dmvnorm(data, mean = mean, sigma = sigma, log = log, ...)
}

score <- function(L1, L2, mu1, mu2) {
  mu_0 <- list(mu1, mu2)
  sum(sapply(1:length(L1), function(i){
    sapply(1:length(L1), function(j){
      vec_norm(mu_0[[L1[i]]][, i] - mu_0[[L1[j]]][, j])
    })
  })) +
    sum(sapply(1:length(L2), function(i){
      sapply(1:length(L2), function(j){
        vec_norm(mu_0[[L2[i]]][, i] - mu_0[[L2[j]]][, j])
      })
    }))
}


score_beta <- function(r, beta) {
  sum(sapply(1:length(r), function(i){
    sapply(1:length(r), function(j){
      vec_norm(r[i]*beta[, i] - r[j]*beta[, j])
    })
  }))
}


score_beta_multi <- function(pihat, mu, Sigma) {
  K <- ncol(pihat)
  R <- nrow(pihat)
  p <- nrow(mu[[1]])
  beta <- sapply(1:R, function(r){
    if(r == 1){
      matrix(0, nrow = p, ncol = K)
    } else {
      sapply(1:K, function(k){
        solve(Sigma[[k]]) %*% (mu[[pihat[r, k]]][, k] - mu[[pihat[1, k]]][, k])
      })
    }
  }, simplify = FALSE)
  sum(sapply(2:R, function(r){
    sum(sapply(1:K, function(i){
      sapply(1:K, function(j){
        vec_norm(beta[[r]][, i] - beta[[r]][, j])
      })
    }))
  }))
}



score_beta_multi_diff_R <- function(pihat, mu, Sigma) {
  K <- nrow(pihat)
  R <- sapply(1:K, function(k){max(pihat[k,],na.rm = T)})
  R_max <- max(R)
  p <- nrow(mu[[1]])
  beta <- sapply(1:K, function(k){
    sapply(1:R_max, function(r){
      if (!is.na(pihat[k,r])) {
        solve(Sigma[[k]]) %*% (mu[[k]][, pihat[k,r]] - mu[[k]][, pihat[k,1]])
      } else {
        rep(NA, p)
      }
    })
  }, simplify = FALSE)
  sum(sapply(2:R_max, function(r){
    if (sum(!is.na(pihat[,r]))>=2) {
      fac <- choose(K, 2)/choose(sum(!is.na(pihat[,r])), 2) # rescaling factor
      sum(sapply(which(!is.na(pihat[,r])), function(i){
        sapply(which(!is.na(pihat[,r])), function(j){
          vec_norm(beta[[i]][, r] - beta[[j]][, r])
        })
      }))*fac
    } else {
      0
    }
  }))
}

#'
#' quiet <- function(x) {
#'   sink(tempfile())
#'   on.exit(sink())
#'   invisible(force(x))
#' }


#' @keywords internal
#' @noRd
beta_fit <- function(C_lambda, x, n, w, mu1, mu2, beta, Sigma, p, K, tol, kappa, iter_max, iter_max_prox, step_size, eta_beta = NULL) {
  lambda.t <- C_lambda*sqrt(max(n))

  for (l in 1:iter_max) {
    lambda.t <- kappa*lambda.t + C_lambda*sqrt(p+log(K))

    gamma <- sapply(1:K, function(k){
      as.numeric(w[k]/(w[k] + (1-w[k])*exp(-t(beta[, k]) %*% (t(x[[k]]) - (mu1[, k] + mu2[, k])/2))))
    }, simplify = FALSE)



    # w
    w.old <- w
    w <- sapply(1:K, function(k){
      a <- mean(gamma[[k]])
      a[a <= 1e-7] <- 1e-7
      a[1-a <= 1e-7] <- 1-1e-7
      a
    })

    # mu1 and mu2
    mu1.old <- mu1
    mu1 <- sapply(1:K, function(k){
      colMeans((1-gamma[[k]])*x[[k]])/(1-w[k])
    })

    mu2.old <- mu2
    mu2 <- sapply(1:K, function(k){
      colMeans(gamma[[k]]*x[[k]])/w[k]
    })


    # Sigma
    Sigma.old <- Sigma
    Sigma <- sapply(1:K, function(k){
      Sigma1 <- t(x[[k]] - matrix(rep(mu1[, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(1-as.numeric(gamma[[k]])) %*% (x[[k]] - matrix(rep(mu1[, k], n[k]), nrow = n[k], byrow = T))
      Sigma2 <- t(x[[k]] - matrix(rep(mu2[, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]])) %*% (x[[k]] - matrix(rep(mu2[, k], n[k]), nrow = n[k], byrow = T))
      (Sigma1+Sigma2)/n[k]
    }, simplify = FALSE)


    # beta
    if (l == 1) {
      beta.bar <- rowMeans(beta)
      beta.t <- beta - beta.bar
    }
    beta.bar.old.last.round <- beta.bar

    eta_beta.list <- sapply(1:K, function(k){
      1/(2*norm(Sigma[[k]], "2"))   # 1/(3*norm(Sigma[[k]], "2"))?
    })
    for (r in 1:iter_max_prox) {
      beta.t.old <- beta.t
      beta.t <- sapply(1:K, function(k){
        eta_beta <- eta_beta.list[k]
        del <- beta.t[, k] - eta_beta*(Sigma[[k]] %*% (beta.t[, k] + beta.bar) + mu1[, k] - mu2[, k])
        max(1-(eta_beta*lambda.t/sqrt(n[k]))/sqrt(sum(del^2)), 0)*del
      })

      Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
        n[k]*Sigma[[k]]
      }, simplify = FALSE))

      vector.weighted.sum <- rowSums(sapply(1:K, function(k){
        n[k]*(-Sigma[[k]]%*%beta.t[, k] - mu1[, k] + mu2[, k])
      }))


      beta.bar.old <- beta.bar
      beta.bar <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

      if (max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)) <= tol) {
        break
      }
      # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))

    }

    beta.old <- beta
    beta <- beta.t + as.numeric(beta.bar)

    # check whether to terminate the interation process or not
    error <- max(vec_max_norm(w-w.old), col_norm(mu1 - mu1.old), col_norm(mu2 - mu2.old), col_norm(beta - beta.old),
                 max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")})), vec_norm(beta.bar - beta.bar.old.last.round))

    if (error <= tol) {
      break
    }
  }
  return(beta)
}



#' @keywords internal
#' @noRd
beta_fit_multi <- function(C_lambda, x, n, w, mu, beta, Sigma, p, K, R, tol, kappa, iter_max, iter_max_prox, step_size, eta_beta = NULL) {
  lambda.t <- C_lambda*sqrt(max(n))

  for (l in 1:iter_max) {

    lambda.t <- kappa*lambda.t + C_lambda*sqrt(p+log(K))

    gamma <- sapply(1:K, function(k){
      gamma_table <- sapply(2:R, function(r){
        # sapply(1:n[k], function(i){
        #   exp(t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
        # })*w[r, k]
        exp(t(beta[[r]][, k]) %*% (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2))*w[r, k]
      })
      if (!any(is.infinite(gamma_table)) && !any(is.na(gamma_table))) {
        gamma_table <- cbind(w[1, k], gamma_table)
        gamma_table[gamma_table == 0] <- 1e-8
        gamma_table/rowSums(gamma_table)
      } else {
        log_gamma_table <- sapply(2:R, function(r){
          # sapply(1:n[k], function(i){
          #   t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2)
          # }) + log(w[r, k])
          t(beta[[r]][, k]) %*% (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2) + log(w[r, k])
        })
        for (i in 1:n[k]) {
          if (any(is.infinite(gamma_table[i, ]))) {
            gamma_ind_sorted <- sort(log_gamma_table[i, ], decreasing = TRUE, index.return = TRUE)
            if (gamma_ind_sorted$x[1] - gamma_ind_sorted$x[2] > 8) {
              gamma_table[i, ] <- rep(0, R-1)
              gamma_table[i, gamma_ind_sorted$ix[1]] <- 1
            } else {
              log_gamma_table[i, ] <- log_gamma_table[i, ] - gamma_ind_sorted$x[2]
              gamma_table[i, ] <- exp(log_gamma_table[i, ])
            }
          }
        }
        gamma_table <- cbind(w[1, k], gamma_table)
        gamma_table[gamma_table == 0] <- 1e-8
        gamma_table/rowSums(gamma_table)
      }

    }, simplify = FALSE)



    # w
    w.old <- w
    w <- sapply(1:K, function(k){
      colMeans(gamma[[k]])
    })

    # mu1 and mu2
    mu.old <- mu
    mu <- sapply(1:R, function(r){
      sapply(1:K, function(k){
        colMeans(gamma[[k]][, r]*x[[k]])/w[r, k]
      })
    }, simplify = FALSE)


    # Sigma
    Sigma.old <- Sigma
    Sigma <- sapply(1:K, function(k){
      # Sigma.list <- sapply(1:R, function(r){
      #   t(x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]][, r])) %*% (x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow = n[k], byrow = T))/n[k]
      # }, simplify = FALSE)
      Sigma.list <- sapply(1:R, function(r){
        (t(x[[k]])-mu[[r]][, k]) %*% (as.numeric(gamma[[k]][, r])*t(t(x[[k]]) - mu[[r]][, k]))/n[k]
      }, simplify = FALSE)
      # Reduce("+", Sigma.list)
      Reduce("+", lapply(Sigma.list, function(S){S[is.na(S)] <- 0;S}))
    }, simplify = FALSE)



    # beta
    if (l == 1) {
      beta.bar <- sapply(1:R, function(r){
        rowMeans(beta[[r]])
      })
      beta.t <- sapply(1:R, function(r){
        beta[[r]] - beta.bar[, r]
      }, simplify = FALSE)
    }
    beta.bar.old.last.round <- beta.bar
    beta.bar.old <- beta.bar

    if (step_size == "lipschitz") {
      eta_beta.list <- sapply(1:K, function(k){
        1/(2*norm(Sigma[[k]], "2"))
      })
    } else if (step_size == "fixed") {
      eta_beta.list <- rep(eta_beta, K)
    }

    beta.t.old <- beta.t
    for (r in 2:R) {
      for (o in 1:iter_max_prox) {
        beta.t[[r]] <- sapply(1:K, function(k){
          eta_beta <- eta_beta.list[k]
          del <- beta.t[[r]][, k] - eta_beta*(Sigma[[k]] %*% (beta.t[[r]][, k] + beta.bar[, r]) + mu[[1]][, k] - mu[[r]][, k])
          max(1-(eta_beta*lambda.t/sqrt(n[k]))/sqrt(sum(del^2)), 0)*del
        })

        Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
          n[k]*Sigma[[k]]
        }, simplify = FALSE))

        vector.weighted.sum <- rowSums(sapply(1:K, function(k){
          n[k]*(-Sigma[[k]]%*%beta.t[[r]][, k] - mu[[1]][, k] + mu[[r]][, k])
        }))


        beta.bar.old[, r] <- beta.bar[, r]
        beta.bar[, r] <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

        if (is.na(max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])))) {
          print("wrong!")
        }
        if (max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])) <= tol) {
          break
        }
        # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))

      }
    }


    beta.old <- beta
    beta <- sapply(1:R, function(r){
      beta.t[[r]] + beta.bar[, r]
    }, simplify = FALSE)

    mu_err <- max(sapply(1:R, function(r){
      col_norm(mu[[r]] - mu.old[[r]])
    }))
    beta_err <- max(sapply(2:R, function(r){
      col_norm(beta[[r]] - beta.old[[r]])
    }))

    w_err <- vec_max_norm(w-w.old)

    Sigma.err <- max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")}))
    # check whether to terminate the interation process or not
    error <- max(w_err, mu_err, beta_err, Sigma.err, col_norm(beta.bar - beta.bar.old.last.round))

    if (error <= tol) {
      break
    }
  }
  return(beta)
}


#' @keywords internal
#' @noRd
beta_fit0 <- function(C_lambda0, x, n, w, mu1, mu2, beta, beta.bar, Sigma, p, K, tol, kappa0, iter_max, iter_max_prox, step_size, eta_beta = NULL) {
  lambda.t <- C_lambda0*sqrt(n)

  for (l in 1:iter_max) {
    gamma <- as.numeric(w/(w + (1-w)*exp(-t(beta) %*% (t(x) - (as.numeric(mu1 + mu2))/2))))

    lambda.t <- kappa0*lambda.t + C_lambda0*sqrt(p)

    # w
    w.old <- w
    w <- mean(gamma)

    # mu1
    mu1.old <- mu1
    mu1 <- colMeans((1-gamma)*x)/(1-w)


    # mu2
    mu2.old <- mu2
    mu2 <- colMeans(gamma*x)/w

    # Sigma
    Sigma.old <- Sigma
    Sigma1 <- t(x - matrix(rep(mu1, n), nrow = n, byrow = T)) %*% diag(1-as.numeric(gamma)) %*% (x - matrix(rep(mu1, n), nrow = n, byrow = T))
    Sigma2 <- t(x - matrix(rep(mu2, n), nrow = n, byrow = T)) %*% diag(as.numeric(gamma)) %*% (x - matrix(rep(mu2, n), nrow = n, byrow = T))
    Sigma <- (Sigma1+Sigma2)/n


    # beta
    if (l == 1) {
      beta.t <- beta - beta.bar
    }
    beta.bar.old.last.round <- beta.bar

    if (step_size == "lipschitz") {
      eta_beta.list <- 1/(2*norm(Sigma, "2"))
    } else if (step_size == "fixed") {
      eta_beta.list <- eta_beta
    }

    for (r in 1:iter_max_prox) {
      beta.t.old <- beta.t

      eta_beta <- eta_beta.list
      del <- beta.t - eta_beta*(Sigma %*% (beta.t + beta.bar) + mu1 - mu2)
      beta.t <- max(1-(eta_beta*lambda.t/sqrt(n))/sqrt(sum(del^2)), 0)*del

      if (col_norm(beta.t - beta.t.old) <= tol) {
        break
      }

    }

    beta.old <- beta
    beta <- beta.t + as.numeric(beta.bar)

    # check whether to terminate the interation process or not
    error <- max(vec_max_norm(w-w.old), vec_norm(mu1 - mu1.old), vec_norm(mu2 - mu2.old), vec_norm(beta - beta.old),
                 norm(Sigma-Sigma.old, "2"))
    if (error <= tol) {
      break
    }
  }
  return(beta)
}


#' @keywords internal
#' @noRd
beta_fit_multi_diff_K <- function(C_lambda, x, n, w, mu, beta, Sigma, p, K, R, tol, kappa, iter_max, iter_max_prox, step_size, eta_beta = NULL) {
  lambda.t <- C_lambda*sqrt(max(n))

  for (l in 1:iter_max) {

    lambda.t <- kappa*lambda.t + C_lambda*sqrt(p+log(K))

    gamma <- sapply(1:K, function(k){
      gamma_table <- sapply(2:R, function(r){
        # sapply(1:n[k], function(i){
        #   exp(t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
        # })*w[r, k]
        exp(t(beta[[r]][, k]) %*% (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2))*w[r, k]
      })
      if (!any(is.infinite(gamma_table))) {
        gamma_table <- cbind(w[1, k], gamma_table)
        gamma_table[gamma_table == 0] <- 1e-8
        gamma_table/rowSums(gamma_table, na.rm = T)
      } else {
        log_gamma_table <- sapply(2:R, function(r){
          # sapply(1:n[k], function(i){
          #   t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2)
          # }) + log(w[r, k])
          t(beta[[r]][, k]) %*% (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k])/2) + log(w[r, k])
        })
        for (i in 1:n[k]) {
          if (any(is.infinite(gamma_table[i, ]))) {
            gamma_ind_sorted <- sort(log_gamma_table[i, ], decreasing = TRUE, index.return = TRUE)
            if (gamma_ind_sorted$x[1] - gamma_ind_sorted$x[2] > 8) {
              gamma_table[i, ] <- rep(0, R-1)
              gamma_table[i, gamma_ind_sorted$ix[1]] <- 1
            } else {
              log_gamma_table[i, ] <- log_gamma_table[i, ] - gamma_ind_sorted$x[2]
              gamma_table[i, ] <- exp(log_gamma_table[i, ])
            }
          }
        }
        gamma_table <- cbind(w[1, k], gamma_table)
        gamma_table[gamma_table == 0] <- 1e-8
        gamma_table/rowSums(gamma_table, na.rm = T)
      }

    }, simplify = FALSE)



    # w
    w.old <- w
    w <- sapply(1:K, function(k){
      colMeans(gamma[[k]])
    })

    # mu1 and mu2
    mu.old <- mu
    mu <- sapply(1:R, function(r){
      sapply(1:K, function(k){
        colMeans(gamma[[k]][, r]*x[[k]])/w[r, k]
      })
    }, simplify = FALSE)


    # Sigma
    Sigma.old <- Sigma
    Sigma <- sapply(1:K, function(k){
      # Sigma.list <- sapply(1:R, function(r){
      #   t(x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]][, r])) %*% (x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow = n[k], byrow = T))/n[k]
      # }, simplify = FALSE)
      Sigma.list <- sapply(1:R, function(r){
        (t(x[[k]])-mu[[r]][, k]) %*% (as.numeric(gamma[[k]][, r])*t(t(x[[k]]) - mu[[r]][, k]))/n[k]
      }, simplify = FALSE)
      # Reduce("+", Sigma.list)
      Reduce("+", lapply(Sigma.list, function(S){S[is.na(S)] <- 0;S}))
    }, simplify = FALSE)



    # beta
    if (l == 1) {
      beta.bar <- sapply(1:R, function(r){
        rowMeans(beta[[r]], na.rm = T)
      })
      beta.t <- sapply(1:R, function(r){
        beta[[r]] - beta.bar[, r]
      }, simplify = FALSE)
    }
    beta.bar.old.last.round <- beta.bar
    beta.bar.old <- beta.bar

    if (step_size == "lipschitz") {
      eta_beta.list <- sapply(1:K, function(k){
        1/(2*norm(Sigma[[k]], "2"))
      })
    } else if (step_size == "fixed") {
      eta_beta.list <- rep(eta_beta, K)
    }

    beta.t.old <- beta.t
    for (r in 2:R) {
      for (o in 1:iter_max_prox) {
        beta.t[[r]] <- sapply(1:K, function(k){
          eta_beta <- eta_beta.list[k]
          del <- beta.t[[r]][, k] - eta_beta*(Sigma[[k]] %*% (beta.t[[r]][, k] + beta.bar[, r]) + mu[[1]][, k] - mu[[r]][, k])
          max(1-(eta_beta*lambda.t/sqrt(n[k]))/sqrt(sum(del^2, na.rm = T)), 0)*del
        })

        Sigma.weighted.sum <- Reduce("+", sapply(1:K, function(k){
          n[k]*Sigma[[k]]*as.numeric(!is.na(w[r,k]))
        }, simplify = FALSE))

        vector.weighted.sum <- rowSums(sapply(1:K, function(k){
          n[k]*(-Sigma[[k]]%*%beta.t[[r]][, k] - mu[[1]][, k] + mu[[r]][, k])
        }), na.rm = T)


        beta.bar.old[, r] <- beta.bar[, r]
        beta.bar[, r] <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

        if (is.na(max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])))) {
          print("wrong!")
        }
        if (max(col_norm(beta.t[[r]] - beta.t.old[[r]]), vec_norm(beta.bar[, r] - beta.bar.old[, r])) <= tol) {
          break
        }
        # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))

      }
    }


    beta.old <- beta
    beta <- sapply(1:R, function(r){
      beta.t[[r]] + beta.bar[, r]
    }, simplify = FALSE)

    mu_err <- max(sapply(1:R, function(r){
      col_norm(mu[[r]] - mu.old[[r]])
    }))
    beta_err <- max(sapply(2:R, function(r){
      col_norm(beta[[r]] - beta.old[[r]])
    }))

    w_err <- vec_max_norm(w-w.old)

    Sigma.err <- max(sapply(1:K, function(k){norm(Sigma[[k]]-Sigma.old[[k]], "2")}))
    # check whether to terminate the interation process or not
    error <- max(w_err, mu_err, beta_err, Sigma.err, col_norm(beta.bar - beta.bar.old.last.round))

    if (error <= tol) {
      break
    }
  }
  return(beta)
}
