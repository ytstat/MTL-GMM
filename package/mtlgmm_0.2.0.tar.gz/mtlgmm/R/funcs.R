# Purpose: Euclidean (L2) norm of a vector
# Inputs:
#   x: numeric vector of length p (NAs allowed; ignored)
# Returns:
#   numeric scalar: sqrt(sum(x^2))
vec_norm <- function(x) {
  sqrt(sum(x^2, na.rm = T))
}

# Purpose: Max column L2 norm of a matrix
# Inputs:
#   x: numeric matrix of size n x p
# Returns:
#   numeric scalar: max_k ||x[,k]||_2
col_norm <- function(x) {
  max(sapply(1:ncol(x), function(k) {
    vec_norm(x[, k])
  }))
}


# Purpose: Infinity norm (max absolute entry) of a vector
# Inputs:
#   x: numeric vector of length p (NAs allowed; ignored)
# Returns:
#   numeric scalar: max(abs(x))
vec_max_norm <- function(x) {
  max(abs(x), na.rm = T)
}

# Purpose: Alias of vec_norm (L2 norm)
# Inputs:
#   x: numeric vector of length p
# Returns:
#   numeric scalar: sqrt(sum(x^2))
norm_vec <- function(x) {
  sqrt(sum(x^2, na.rm = T))
}


# Purpose: NA-safe wrapper of mvtnorm::dmvnorm
# Behavior: if a non-NULL mean contains NA, returns a length-n vector of NA_real_
# Inputs:
#   data: numeric vector (length p) or matrix (n x p)
#   mean: numeric vector length p or NULL
#   sigma: numeric covariance matrix p x p
#   log: logical; return log-density if TRUE
#   ...: passed to mvtnorm::dmvnorm
# Returns:
#   numeric vector length n (or 1 if data is a vector)
safe_dmvnorm <- function(data, mean = NULL, sigma = NULL, log = FALSE, ...) {
  # If mean was left at default mvtnorm will build it inside,
  # otherwise check for missing values:
  if (!is.null(mean) && anyNA(mean)) {
    # return the right length of NA_real_
    n <- if (is.matrix(data)) nrow(data) else length(data)
    return(rep(NA_real_, n))
  }
  dmvnorm(data, mean = mean, sigma = sigma, log = log, ...)
}

# Purpose: Alignment score under two label permutations
# Description: sums pairwise L2 distances between columns of mean matrices under
#   permutations L1 and L2; diagnostic for alignment quality
# Inputs:
#   L1: integer vector length K; labels for mu1 columns
#   L2: integer vector length K; labels for mu2 columns
#   mu1: numeric matrix p x K
#   mu2: numeric matrix p x K
# Returns:
#   numeric scalar
score <- function(L1, L2, mu1, mu2) {
  mu_0 <- list(mu1, mu2)
  sum(sapply(1:length(L1), function(i) {
    sapply(1:length(L1), function(j) {
      vec_norm(mu_0[[L1[i]]][, i] - mu_0[[L1[j]]][, j])
    })
  })) +
    sum(sapply(1:length(L2), function(i) {
      sapply(1:length(L2), function(j) {
        vec_norm(mu_0[[L2[i]]][, i] - mu_0[[L2[j]]][, j])
      })
    }))
}


# Purpose: Pairwise distance score of beta columns (for the binary case)
# Inputs:
#   r: numeric vector length K; scaling per column
#   beta: numeric matrix p x K; columns are beta vectors
# Returns:
#   numeric scalar sum_{i,j} ||r[i]*beta[,i] - r[j]*beta[,j]||_2
score_beta <- function(r, beta) {
  sum(sapply(1:length(r), function(i) {
    sapply(1:length(r), function(j) {
      vec_norm(r[i] * beta[, i] - r[j] * beta[, j])
    })
  }))
}


# Purpose: Multi-task beta alignment score (for multiple clusters but identical cluster number R across tasks)
# Description: constructs task-specific beta via Sigma^{-1}(mu_r - mu_1) then
#   sums pairwise column distances for each task r>=2
# Inputs:
#   pihat: integer matrix R x K; permutation per task r
#   mu: list length R; each element p x K mean matrix for task r
#   Sigma: list length K; each element p x p covariance for component k
# Returns:
#   numeric scalar
score_beta_multi <- function(pihat, mu, Sigma) {
  K <- ncol(pihat)
  R <- nrow(pihat)
  p <- nrow(mu[[1]])
  beta <- sapply(
    1:R,
    function(r) {
      if (r == 1) {
        matrix(0, nrow = p, ncol = K)
      } else {
        sapply(1:K, function(k) {
          solve(Sigma[[k]]) %*%
            (mu[[pihat[r, k]]][, k] - mu[[pihat[1, k]]][, k])
        })
      }
    },
    simplify = FALSE
  )
  sum(sapply(2:R, function(r) {
    sum(sapply(1:K, function(i) {
      sapply(1:K, function(j) {
        vec_norm(beta[[r]][, i] - beta[[r]][, j])
      })
    }))
  }))
}


# Purpose: Multi-task beta score with varying number of clusters per component
# Description: allows NA in pihat, builds beta per available task, rescales by
#   available pairs when fewer than K datasets exist for a given r
# Inputs:
#   pihat: integer matrix K x R_max with possible NA entries
#   mu: list length K; each element p x R_k mean matrix for component k
#   Sigma: list length K; each element p x p covariance for component k
# Returns:
#   numeric scalar
score_beta_multi_diff_R <- function(pihat, mu, Sigma) {
  K <- nrow(pihat)
  R <- sapply(1:K, function(k) {
    max(pihat[k, ], na.rm = T)
  })
  R_max <- max(R)
  p <- nrow(mu[[1]])
  beta <- sapply(
    1:K,
    function(k) {
      sapply(1:R_max, function(r) {
        if (!is.na(pihat[k, r])) {
          solve(Sigma[[k]]) %*%
            (mu[[k]][, pihat[k, r]] - mu[[k]][, pihat[k, 1]])
        } else {
          rep(NA, p)
        }
      })
    },
    simplify = FALSE
  )
  sum(sapply(2:R_max, function(r) {
    if (sum(!is.na(pihat[, r])) >= 2) {
      fac <- choose(K, 2) / choose(sum(!is.na(pihat[, r])), 2) # rescaling factor
      sum(sapply(which(!is.na(pihat[, r])), function(i) {
        sapply(which(!is.na(pihat[, r])), function(j) {
          vec_norm(beta[[i]][, r] - beta[[j]][, r])
        })
      })) *
        fac
    } else {
      0
    }
  }))
}

#'
#' quiet <- function(x) {
#'   sink(tempfile())
#'   on.exit(sink())
#'   invisible(force(x))
#' }

# Purpose: EM algorithm to fit the coefficient for the binary MTL problem
#' @keywords internal
#' @noRd
## Inputs (dimensions):
##   C_lambda: numeric scalar; base constant controlling group-lasso regularization strength
##   x: list length K; each element is an n[k] x p numeric matrix (per-dataset design; rows=samples, cols=features)
##   n: integer vector length K; sample sizes per dataset matching x[[k]]
##   w: numeric vector length K; mixture proportion (probability of component 2) per dataset
##   mu1, mu2: numeric matrices p x K; component means for clusters 1 and 2 (columns index datasets)
##   beta: numeric matrix p x K; discriminant vectors per dataset to be updated
##   Sigma: list length K; each element is a p x p numeric covariance matrix (shared across components)
##   p: integer; feature dimensionality (number of columns in x[[k]])
##   K: integer; number of datasets/tasks
##   tol: numeric scalar; stopping threshold for iterative updates
##   kappa: numeric scalar; decay factor for lambda schedule across iterations
##   iter_max: integer scalar; maximum outer EM/proximal iterations
##   iter_max_prox: integer scalar; maximum inner proximal iterations for beta updates
##   step_size: character scalar ("lipschitz" or "fixed"); proximal step sizing strategy
##   eta_beta: numeric scalar; fixed step size used when step_size == "fixed"
## Returns:
##   numeric matrix p x K (updated beta)
beta_fit <- function(
  C_lambda,
  x,
  n,
  w,
  mu1,
  mu2,
  beta,
  Sigma,
  p,
  K,
  tol,
  kappa,
  iter_max,
  iter_max_prox,
  step_size,
  eta_beta = NULL
) {
  lambda.t <- C_lambda * sqrt(max(n))

  for (l in 1:iter_max) {
    lambda.t <- kappa * lambda.t + C_lambda * sqrt(p + log(K))

    gamma <- sapply(
      1:K,
      function(k) {
        as.numeric(
          w[k] /
            (w[k] +
              (1 - w[k]) *
                exp(-t(beta[, k]) %*% (t(x[[k]]) - (mu1[, k] + mu2[, k]) / 2)))
        )
      },
      simplify = FALSE
    )

    # w
    w.old <- w
    w <- sapply(1:K, function(k) {
      a <- mean(gamma[[k]])
      a[a <= 1e-7] <- 1e-7
      a[1 - a <= 1e-7] <- 1 - 1e-7
      a
    })

    # mu1 and mu2
    mu1.old <- mu1
    mu1 <- sapply(1:K, function(k) {
      colMeans((1 - gamma[[k]]) * x[[k]]) / (1 - w[k])
    })

    mu2.old <- mu2
    mu2 <- sapply(1:K, function(k) {
      colMeans(gamma[[k]] * x[[k]]) / w[k]
    })

    # Sigma
    Sigma.old <- Sigma
    Sigma <- sapply(
      1:K,
      function(k) {
        Sigma1 <- t(
          x[[k]] - matrix(rep(mu1[, k], n[k]), nrow = n[k], byrow = T)
        ) %*%
          diag(1 - as.numeric(gamma[[k]])) %*%
          (x[[k]] - matrix(rep(mu1[, k], n[k]), nrow = n[k], byrow = T))
        Sigma2 <- t(
          x[[k]] - matrix(rep(mu2[, k], n[k]), nrow = n[k], byrow = T)
        ) %*%
          diag(as.numeric(gamma[[k]])) %*%
          (x[[k]] - matrix(rep(mu2[, k], n[k]), nrow = n[k], byrow = T))
        (Sigma1 + Sigma2) / n[k]
      },
      simplify = FALSE
    )

    # beta
    if (l == 1) {
      beta.bar <- rowMeans(beta)
      beta.t <- beta - beta.bar
    }
    beta.bar.old.last.round <- beta.bar

    eta_beta.list <- sapply(1:K, function(k) {
      1 / (2 * norm(Sigma[[k]], "2")) # 1/(3*norm(Sigma[[k]], "2"))?
    })
    for (r in 1:iter_max_prox) {
      beta.t.old <- beta.t
      beta.t <- sapply(1:K, function(k) {
        eta_beta <- eta_beta.list[k]
        del <- beta.t[, k] -
          eta_beta *
            (Sigma[[k]] %*% (beta.t[, k] + beta.bar) + mu1[, k] - mu2[, k])
        max(1 - (eta_beta * lambda.t / sqrt(n[k])) / sqrt(sum(del^2)), 0) * del
      })

      Sigma.weighted.sum <- Reduce(
        "+",
        sapply(
          1:K,
          function(k) {
            n[k] * Sigma[[k]]
          },
          simplify = FALSE
        )
      )

      vector.weighted.sum <- rowSums(sapply(1:K, function(k) {
        n[k] * (-Sigma[[k]] %*% beta.t[, k] - mu1[, k] + mu2[, k])
      }))

      beta.bar.old <- beta.bar
      beta.bar <- as.numeric(solve(Sigma.weighted.sum) %*% vector.weighted.sum)

      if (
        max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)) <=
          tol
      ) {
        break
      }
      # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))
    }

    beta.old <- beta
    beta <- beta.t + as.numeric(beta.bar)

    # check whether to terminate the interation process or not
    error <- max(
      vec_max_norm(w - w.old),
      col_norm(mu1 - mu1.old),
      col_norm(mu2 - mu2.old),
      col_norm(beta - beta.old),
      max(sapply(1:K, function(k) {
        norm(Sigma[[k]] - Sigma.old[[k]], "2")
      })),
      vec_norm(beta.bar - beta.bar.old.last.round)
    )

    if (error <= tol) {
      break
    }
  }
  return(beta)
}

# Purpose: EM algorithm to fit the coefficient for the multi-cluster MTL problem
#' @keywords internal
#' @noRd
## Inputs (dimensions):
##   C_lambda: numeric scalar; base constant controlling group-lasso regularization
##   x: list length K; each element is an n[k] x p numeric matrix (design per dataset)
##   n: integer vector length K; sample sizes per dataset
##   w: numeric matrix R x K; class proportions per dataset (rows=classes, cols=datasets)
##   mu: list length R; each element is a p x K numeric mean matrix (class-specific means per dataset)
##   beta: list length R; each element is a p x K numeric matrix (class-specific discriminants per dataset)
##   Sigma: list length K; each element is a p x p numeric covariance matrix (per dataset)
##   p: integer; feature dimensionality
##   K: integer; number of datasets/tasks
##   R: integer; number of classes/components
##   tol: numeric scalar; convergence tolerance
##   kappa: numeric scalar; decay factor for lambda schedule
##   iter_max: integer scalar; maximum outer iterations
##   iter_max_prox: integer scalar; maximum inner proximal iterations
##   step_size: character scalar ("lipschitz" or "fixed"); proximal step strategy; eta_beta: numeric when fixed
## Returns:
##   list length R of p x K matrices (updated beta per class)
beta_fit_multi <- function(
  C_lambda,
  x,
  n,
  w,
  mu,
  beta,
  Sigma,
  p,
  K,
  R,
  tol,
  kappa,
  iter_max,
  iter_max_prox,
  step_size,
  eta_beta = NULL
) {
  lambda.t <- C_lambda * sqrt(max(n))

  for (l in 1:iter_max) {
    lambda.t <- kappa * lambda.t + C_lambda * sqrt(p + log(K))

    gamma <- sapply(
      1:K,
      function(k) {
        gamma_table <- sapply(2:R, function(r) {
          # sapply(1:n[k], function(i){
          #   exp(t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
          # })*w[r, k]
          exp(
            t(beta[[r]][, k]) %*%
              (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k]) / 2)
          ) *
            w[r, k]
        })
        if (!any(is.infinite(gamma_table)) && !any(is.na(gamma_table))) {
          gamma_table <- cbind(w[1, k], gamma_table)
          gamma_table[gamma_table == 0] <- 1e-8
          gamma_table / rowSums(gamma_table)
        } else {
          log_gamma_table <- sapply(2:R, function(r) {
            # sapply(1:n[k], function(i){
            #   t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2)
            # }) + log(w[r, k])
            t(beta[[r]][, k]) %*%
              (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k]) / 2) +
              log(w[r, k])
          })
          for (i in 1:n[k]) {
            if (any(is.infinite(gamma_table[i, ]))) {
              gamma_ind_sorted <- sort(
                log_gamma_table[i, ],
                decreasing = TRUE,
                index.return = TRUE
              )
              if (gamma_ind_sorted$x[1] - gamma_ind_sorted$x[2] > 8) {
                gamma_table[i, ] <- rep(0, R - 1)
                gamma_table[i, gamma_ind_sorted$ix[1]] <- 1
              } else {
                log_gamma_table[i, ] <- log_gamma_table[i, ] -
                  gamma_ind_sorted$x[2]
                gamma_table[i, ] <- exp(log_gamma_table[i, ])
              }
            }
          }
          gamma_table <- cbind(w[1, k], gamma_table)
          gamma_table[gamma_table == 0] <- 1e-8
          gamma_table / rowSums(gamma_table)
        }
      },
      simplify = FALSE
    )

    # w
    w.old <- w
    w <- sapply(1:K, function(k) {
      colMeans(gamma[[k]])
    })

    # mu1 and mu2
    mu.old <- mu
    mu <- sapply(
      1:R,
      function(r) {
        sapply(1:K, function(k) {
          colMeans(gamma[[k]][, r] * x[[k]]) / w[r, k]
        })
      },
      simplify = FALSE
    )

    # Sigma
    Sigma.old <- Sigma
    Sigma <- sapply(
      1:K,
      function(k) {
        # Sigma.list <- sapply(1:R, function(r){
        #   t(x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]][, r])) %*% (x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow = n[k], byrow = T))/n[k]
        # }, simplify = FALSE)
        Sigma.list <- sapply(
          1:R,
          function(r) {
            (t(x[[k]]) - mu[[r]][, k]) %*%
              (as.numeric(gamma[[k]][, r]) * t(t(x[[k]]) - mu[[r]][, k])) /
              n[k]
          },
          simplify = FALSE
        )
        # Reduce("+", Sigma.list)
        Reduce(
          "+",
          lapply(Sigma.list, function(S) {
            S[is.na(S)] <- 0
            S
          })
        )
      },
      simplify = FALSE
    )

    # beta
    if (l == 1) {
      beta.bar <- sapply(1:R, function(r) {
        rowMeans(beta[[r]])
      })
      beta.t <- sapply(
        1:R,
        function(r) {
          beta[[r]] - beta.bar[, r]
        },
        simplify = FALSE
      )
    }
    beta.bar.old.last.round <- beta.bar
    beta.bar.old <- beta.bar

    if (step_size == "lipschitz") {
      eta_beta.list <- sapply(1:K, function(k) {
        1 / (2 * norm(Sigma[[k]], "2"))
      })
    } else if (step_size == "fixed") {
      eta_beta.list <- rep(eta_beta, K)
    }

    beta.t.old <- beta.t
    for (r in 2:R) {
      for (o in 1:iter_max_prox) {
        beta.t[[r]] <- sapply(1:K, function(k) {
          eta_beta <- eta_beta.list[k]
          del <- beta.t[[r]][, k] -
            eta_beta *
              (Sigma[[k]] %*%
                (beta.t[[r]][, k] + beta.bar[, r]) +
                mu[[1]][, k] -
                mu[[r]][, k])
          max(1 - (eta_beta * lambda.t / sqrt(n[k])) / sqrt(sum(del^2)), 0) *
            del
        })

        Sigma.weighted.sum <- Reduce(
          "+",
          sapply(
            1:K,
            function(k) {
              n[k] * Sigma[[k]]
            },
            simplify = FALSE
          )
        )

        vector.weighted.sum <- rowSums(sapply(1:K, function(k) {
          n[k] *
            (-Sigma[[k]] %*% beta.t[[r]][, k] - mu[[1]][, k] + mu[[r]][, k])
        }))

        beta.bar.old[, r] <- beta.bar[, r]
        beta.bar[, r] <- as.numeric(
          solve(Sigma.weighted.sum) %*% vector.weighted.sum
        )

        if (
          is.na(max(
            col_norm(beta.t[[r]] - beta.t.old[[r]]),
            vec_norm(beta.bar[, r] - beta.bar.old[, r])
          ))
        ) {
          print("wrong!")
        }
        if (
          max(
            col_norm(beta.t[[r]] - beta.t.old[[r]]),
            vec_norm(beta.bar[, r] - beta.bar.old[, r])
          ) <=
            tol
        ) {
          break
        }
        # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))
      }
    }

    beta.old <- beta
    beta <- sapply(
      1:R,
      function(r) {
        beta.t[[r]] + beta.bar[, r]
      },
      simplify = FALSE
    )

    mu_err <- max(sapply(1:R, function(r) {
      col_norm(mu[[r]] - mu.old[[r]])
    }))
    beta_err <- max(sapply(2:R, function(r) {
      col_norm(beta[[r]] - beta.old[[r]])
    }))

    w_err <- vec_max_norm(w - w.old)

    Sigma.err <- max(sapply(1:K, function(k) {
      norm(Sigma[[k]] - Sigma.old[[k]], "2")
    }))
    # check whether to terminate the interation process or not
    error <- max(
      w_err,
      mu_err,
      beta_err,
      Sigma.err,
      col_norm(beta.bar - beta.bar.old.last.round)
    )

    if (error <= tol) {
      break
    }
  }
  return(beta)
}

# Purpose: EM algorithm to fit the target coefficient for the binary TL problem
#' @keywords internal
#' @noRd
## Inputs (dimensions):
##   C_lambda0: numeric scalar; base regularization constant (single dataset)
##   x: numeric matrix n x p; design for the single dataset (rows=samples, cols=features)
##   n: integer scalar; sample size
##   w: numeric scalar; mixture proportion (probability of component 2)
##   mu1, mu2: numeric vectors length p; component mean vectors
##   beta, beta.bar: numeric vectors length p; discriminant and its average used in proximal splitting
##   Sigma: numeric covariance matrix p x p (single dataset)
##   p: integer; feature dimensionality; K: integer (unused here)
##   tol: numeric scalar; convergence tolerance; kappa0: numeric scalar; decay factor
##   iter_max: integer scalar; maximum outer iterations; iter_max_prox: integer scalar; maximum inner proximal iterations
##   step_size: character scalar; proximal step sizing strategy; eta_beta: numeric scalar when fixed
## Returns:
##   numeric vector length p (updated beta)
beta_fit0 <- function(
  C_lambda0,
  x,
  n,
  w,
  mu1,
  mu2,
  beta,
  beta.bar,
  Sigma,
  p,
  K,
  tol,
  kappa0,
  iter_max,
  iter_max_prox,
  step_size,
  eta_beta = NULL
) {
  lambda.t <- C_lambda0 * sqrt(n)

  for (l in 1:iter_max) {
    gamma <- as.numeric(
      w / (w + (1 - w) * exp(-t(beta) %*% (t(x) - (as.numeric(mu1 + mu2)) / 2)))
    )

    lambda.t <- kappa0 * lambda.t + C_lambda0 * sqrt(p)

    # w
    w.old <- w
    w <- mean(gamma)

    # mu1
    mu1.old <- mu1
    mu1 <- colMeans((1 - gamma) * x) / (1 - w)

    # mu2
    mu2.old <- mu2
    mu2 <- colMeans(gamma * x) / w

    # Sigma
    Sigma.old <- Sigma
    Sigma1 <- t(x - matrix(rep(mu1, n), nrow = n, byrow = T)) %*%
      diag(1 - as.numeric(gamma)) %*%
      (x - matrix(rep(mu1, n), nrow = n, byrow = T))
    Sigma2 <- t(x - matrix(rep(mu2, n), nrow = n, byrow = T)) %*%
      diag(as.numeric(gamma)) %*%
      (x - matrix(rep(mu2, n), nrow = n, byrow = T))
    Sigma <- (Sigma1 + Sigma2) / n

    # beta
    if (l == 1) {
      beta.t <- beta - beta.bar
    }
    beta.bar.old.last.round <- beta.bar

    if (step_size == "lipschitz") {
      eta_beta.list <- 1 / (2 * norm(Sigma, "2"))
    } else if (step_size == "fixed") {
      eta_beta.list <- eta_beta
    }

    for (r in 1:iter_max_prox) {
      beta.t.old <- beta.t

      eta_beta <- eta_beta.list
      del <- beta.t - eta_beta * (Sigma %*% (beta.t + beta.bar) + mu1 - mu2)
      beta.t <- max(1 - (eta_beta * lambda.t / sqrt(n)) / sqrt(sum(del^2)), 0) *
        del

      if (col_norm(beta.t - beta.t.old) <= tol) {
        break
      }
    }

    beta.old <- beta
    beta <- beta.t + as.numeric(beta.bar)

    # check whether to terminate the interation process or not
    error <- max(
      vec_max_norm(w - w.old),
      vec_norm(mu1 - mu1.old),
      vec_norm(mu2 - mu2.old),
      vec_norm(beta - beta.old),
      norm(Sigma - Sigma.old, "2")
    )
    if (error <= tol) {
      break
    }
  }
  return(beta)
}

# Purpose: EM algorithm to fit the coefficient for the multi-cluster MTL problem with different number of classes in each task
#' @keywords internal
#' @noRd
## Inputs (dimensions):
##   C_lambda: numeric scalar; base constant controlling group-lasso regularization
##   x: list length K; each element is an n[k] x p numeric matrix (design per dataset)
##   n: integer vector length K; sample sizes per dataset
##   w: numeric matrix R x K; class proportions per dataset (may contain NA for missing tasks)
##   mu: list length R; each element is a p x K numeric mean matrix (may include NA where missing)
##   beta: list length R; each element is a p x K numeric matrix (may include NA where missing)
##   Sigma: list length K; each element is a p x p numeric covariance matrix (per dataset)
##   p: integer; feature dimensionality; K: integer; number of datasets; R: integer; number of classes
##   tol: numeric scalar; convergence tolerance; kappa: numeric scalar; decay factor
##   iter_max: integer scalar; maximum outer iterations; iter_max_prox: integer scalar; maximum inner proximal iterations
##   step_size: character scalar; proximal step sizing strategy; eta_beta: numeric scalar when fixed
## Returns:
##   list length R of p x K matrices (updated beta per class)
beta_fit_multi_diff_K <- function(
  C_lambda,
  x,
  n,
  w,
  mu,
  beta,
  Sigma,
  p,
  K,
  R,
  tol,
  kappa,
  iter_max,
  iter_max_prox,
  step_size,
  eta_beta = NULL
) {
  lambda.t <- C_lambda * sqrt(max(n))

  for (l in 1:iter_max) {
    lambda.t <- kappa * lambda.t + C_lambda * sqrt(p + log(K))

    gamma <- sapply(
      1:K,
      function(k) {
        gamma_table <- sapply(2:R, function(r) {
          # sapply(1:n[k], function(i){
          #   exp(t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2))
          # })*w[r, k]
          exp(
            t(beta[[r]][, k]) %*%
              (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k]) / 2)
          ) *
            w[r, k]
        })
        if (!any(is.infinite(gamma_table))) {
          gamma_table <- cbind(w[1, k], gamma_table)
          gamma_table[gamma_table == 0] <- 1e-8
          gamma_table / rowSums(gamma_table, na.rm = T)
        } else {
          log_gamma_table <- sapply(2:R, function(r) {
            # sapply(1:n[k], function(i){
            #   t(beta[[r]][, k]) %*% (x[[k]][i, ] - (mu[[r]][, k] + mu[[1]][, k])/2)
            # }) + log(w[r, k])
            t(beta[[r]][, k]) %*%
              (t(x[[k]]) - (mu[[r]][, k] + mu[[1]][, k]) / 2) +
              log(w[r, k])
          })
          for (i in 1:n[k]) {
            if (any(is.infinite(gamma_table[i, ]))) {
              gamma_ind_sorted <- sort(
                log_gamma_table[i, ],
                decreasing = TRUE,
                index.return = TRUE
              )
              if (gamma_ind_sorted$x[1] - gamma_ind_sorted$x[2] > 8) {
                gamma_table[i, ] <- rep(0, R - 1)
                gamma_table[i, gamma_ind_sorted$ix[1]] <- 1
              } else {
                log_gamma_table[i, ] <- log_gamma_table[i, ] -
                  gamma_ind_sorted$x[2]
                gamma_table[i, ] <- exp(log_gamma_table[i, ])
              }
            }
          }
          gamma_table <- cbind(w[1, k], gamma_table)
          gamma_table[gamma_table == 0] <- 1e-8
          gamma_table / rowSums(gamma_table, na.rm = T)
        }
      },
      simplify = FALSE
    )

    # w
    w.old <- w
    w <- sapply(1:K, function(k) {
      colMeans(gamma[[k]])
    })

    # mu1 and mu2
    mu.old <- mu
    mu <- sapply(
      1:R,
      function(r) {
        sapply(1:K, function(k) {
          colMeans(gamma[[k]][, r] * x[[k]]) / w[r, k]
        })
      },
      simplify = FALSE
    )

    # Sigma
    Sigma.old <- Sigma
    Sigma <- sapply(
      1:K,
      function(k) {
        # Sigma.list <- sapply(1:R, function(r){
        #   t(x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow =  n[k], byrow = T)) %*% diag(as.numeric(gamma[[k]][, r])) %*% (x[[k]] - matrix(rep(mu[[r]][, k], n[k]), nrow = n[k], byrow = T))/n[k]
        # }, simplify = FALSE)
        Sigma.list <- sapply(
          1:R,
          function(r) {
            (t(x[[k]]) - mu[[r]][, k]) %*%
              (as.numeric(gamma[[k]][, r]) * t(t(x[[k]]) - mu[[r]][, k])) /
              n[k]
          },
          simplify = FALSE
        )
        # Reduce("+", Sigma.list)
        Reduce(
          "+",
          lapply(Sigma.list, function(S) {
            S[is.na(S)] <- 0
            S
          })
        )
      },
      simplify = FALSE
    )

    # beta
    if (l == 1) {
      beta.bar <- sapply(1:R, function(r) {
        rowMeans(beta[[r]], na.rm = T)
      })
      beta.t <- sapply(
        1:R,
        function(r) {
          beta[[r]] - beta.bar[, r]
        },
        simplify = FALSE
      )
    }
    beta.bar.old.last.round <- beta.bar
    beta.bar.old <- beta.bar

    if (step_size == "lipschitz") {
      eta_beta.list <- sapply(1:K, function(k) {
        1 / (2 * norm(Sigma[[k]], "2"))
      })
    } else if (step_size == "fixed") {
      eta_beta.list <- rep(eta_beta, K)
    }

    beta.t.old <- beta.t
    for (r in 2:R) {
      for (o in 1:iter_max_prox) {
        beta.t[[r]] <- sapply(1:K, function(k) {
          eta_beta <- eta_beta.list[k]
          del <- beta.t[[r]][, k] -
            eta_beta *
              (Sigma[[k]] %*%
                (beta.t[[r]][, k] + beta.bar[, r]) +
                mu[[1]][, k] -
                mu[[r]][, k])
          max(
            1 -
              (eta_beta * lambda.t / sqrt(n[k])) / sqrt(sum(del^2, na.rm = T)),
            0
          ) *
            del
        })

        Sigma.weighted.sum <- Reduce(
          "+",
          sapply(
            1:K,
            function(k) {
              n[k] * Sigma[[k]] * as.numeric(!is.na(w[r, k]))
            },
            simplify = FALSE
          )
        )

        vector.weighted.sum <- rowSums(
          sapply(1:K, function(k) {
            n[k] *
              (-Sigma[[k]] %*% beta.t[[r]][, k] - mu[[1]][, k] + mu[[r]][, k])
          }),
          na.rm = T
        )

        beta.bar.old[, r] <- beta.bar[, r]
        beta.bar[, r] <- as.numeric(
          solve(Sigma.weighted.sum) %*% vector.weighted.sum
        )

        if (
          is.na(max(
            col_norm(beta.t[[r]] - beta.t.old[[r]]),
            vec_norm(beta.bar[, r] - beta.bar.old[, r])
          ))
        ) {
          print("wrong!")
        }
        if (
          max(
            col_norm(beta.t[[r]] - beta.t.old[[r]]),
            vec_norm(beta.bar[, r] - beta.bar.old[, r])
          ) <=
            tol
        ) {
          break
        }
        # print(max(col_norm(beta.t - beta.t.old), vec_norm(beta.bar - beta.bar.old)))
      }
    }

    beta.old <- beta
    beta <- sapply(
      1:R,
      function(r) {
        beta.t[[r]] + beta.bar[, r]
      },
      simplify = FALSE
    )

    mu_err <- max(sapply(1:R, function(r) {
      col_norm(mu[[r]] - mu.old[[r]])
    }))
    beta_err <- max(sapply(2:R, function(r) {
      col_norm(beta[[r]] - beta.old[[r]])
    }))

    w_err <- vec_max_norm(w - w.old)

    Sigma.err <- max(sapply(1:K, function(k) {
      norm(Sigma[[k]] - Sigma.old[[k]], "2")
    }))
    # check whether to terminate the interation process or not
    error <- max(
      w_err,
      mu_err,
      beta_err,
      Sigma.err,
      col_norm(beta.bar - beta.bar.old.last.round)
    )

    if (error <= tol) {
      break
    }
  }
  return(beta)
}
