#' @title Fit the binary Gaussian mixture model (GMM) on target data set by leveraging multiple source data sets under a transfer learning (TL) setting.
#'
#' @description Fit the binary Gaussian mixture model (GMM) on target data set by leveraging multiple source data sets under a transfer learning (TL) setting. This function implements the modified EM algorithm (Altorithm 4) proposed in Tian, Y. et al. (2022).
#' @export
#' @param x design matrix of the target data set. Should be a \code{matrix} or \code{data.frame} object.
#' @param fitted_bar the output from \code{mtlgmm} function.
#' @param step_size step size choice in proximal gradient method to solve each optimization problem in the revised EM algorithm (Algorithm 1 in Tian, Y. et al. (2022)), which can be either "lipschitz" or "fixed". Default = "lipschitz".
#' \itemize{
#' \item lipschitz: \code{eta_w}, \code{eta_mu} and \code{eta_beta} will be chosen by the Lipschitz property of the gradient of objective function (without the penalty part). See Section 4.2 of Parikh, N., & Boyd, S. (2014).
#' \item fixed: \code{eta_w}, \code{eta_mu} and \code{eta_beta} need to be specified
#' }
#' @param eta_beta step size in the proximal gradient method to learn beta (Step 6 of Algorithm 7 in Tian, Y. et al. (2022)). Default: 0.1. Only used when \code{step_size} = "fixed".
#' @param lambda_choice the choice of constants in the penalty parameter used in the optimization problems. See Algorithm 4 of Tian, Y. et al. (2022), which can be either "fixed" or "cv". Default = "cv".
#' \itemize{
#' \item cv: \code{cv_nfolds}, \code{cv_upper}, and \code{cv_length} need to be specified. Then the C1 and C2 parameters will be chosen in all combinations in \code{exp(seq(log(cv_lower/10), log(cv_upper/10), length.out = cv_length))} via cross-validation. Note that this is a two-dimensional cv process, because we set \code{C1_w} = \code{C2_w}, \code{C1_mu} = \code{C1_beta} = \code{C2_mu} = \code{C2_beta} to reduce the computational cost.
#' \item fixed: \code{C1_w}, \code{C1_mu}, \code{C1_beta}, \code{C2_w}, \code{C2_mu}, and \code{C2_beta} need to be specified. See equations (19)-(24) in Tian, Y. et al. (2022).
#' }
#' @param cv_nfolds the number of cross-validation folds. Default: 5
#' @param cv_upper the upper bound of \code{lambda} values used in cross-validation. Default: 5
#' @param cv_lower the lower bound of \code{lambda} values used in cross-validation. Default: 0.01
#' @param cv_length the number of \code{lambda} values considered in cross-validation. Default: 5
#' @param C_lambda0 the initial value of C_lambda0 in Step 2 of Algorithm 7 in Tian, Y. et al. (2022). Default: 1
#' @param kappa0 the decaying rate used in Step 2 of Algorithm 7 in Tian, Y. et al. (2022). Default: 1/3
#' @param tol maximum tolerance in all optimization problems. If the difference between last update and the current update is less than this value, the iterations of optimization will stop. Default: 1e-05
#' @param initial_method initialization method. This indicates the method to initialize the estimates of GMM parameters for each data set. Can be either "kmeans" or "EM".
#' \itemize{
#' \item kmeans: the initial estimates of GMM parameters will be generated from the single-task k-means algorithm. Will call \code{\link[stats]{kmeans}} function in \code{stats} package.
#' \item EM: the initial estimates of GMM parameters will be generated from the single-task EM algorithm. Will call \code{\link[mclust]{Mclust}} function in \code{mclust} package.
#' }
#' @param iter_max the maximum iteration number of the revised EM algorithm (i.e. the parameter T in Algorithm 1 in Tian, Y. et al. (2022)). Default: 1000
#' @param iter_max_prox the maximum iteration number of the proximal gradient method. Default: 100
#' @param ncores the number of cores to use. Parallel computing is strongly suggested, specially when \code{lambda_choice} = "cv". Default: 1
#' @return A list with the following components.
#' \item{w}{the estimate of mixture proportion in GMMs for the target task. Will be a vector.}
#' \item{mu1}{the estimate of Gaussian mean in the first cluster of GMMs for the target task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{mu2}{the estimate of Gaussian mean in the second cluster of GMMs for the target task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{beta}{the estimate of the discriminant coefficient for the target task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{Sigma}{the estimate of the common covariance matrix for the target task. Will be a list, where each component represents the estimate for a task.}
#' \item{C_lambda0}{the value of C_lambda0 used in the algorithm.}
#' @seealso \code{\link{mtlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'
#' Parikh, N., & Boyd, S. (2014). Proximal algorithms. Foundations and trends in Optimization, 1(3), 127-239.
#'
#' @examples
#' \donttest{
#' set.seed(0, kind = "L'Ecuyer-CMRG")
#' ## Consider a transfer learning problem with 3 source tasks and 1 target task in the setting "MTL-1"
#' data_list_source <- data_generation(K = 3, outlier_K = 0, simulation_no = "MTL-1", h = 1,
#' n = 50)  # generate the source data
#' data_target <- data_generation(K = 1, outlier_K = 0, simulation_no = "MTL-1", h = 1,
#' n = 50)  # generate the target data
#' fit <- mtlgmm(x = data_list_source$data$x, kappa = 1/3, initial_method = "EM", cv_nfolds = 5,
#'               cv_upper = "auto", cv_length = 5, lambda_choice = "cv",
#'               step_size = "lipschitz", tol = 1e-3, trim = 0.1, ncores = 2)
#' fit.tl <- tlgmm(x = data_target$data$x[[1]], fitted_bar = fit, kappa0 = 1/3, initial_method = "EM",
#'                 ncores = 2, cv_length = 5, cv_upper = "auto",
#'                lambda_choice = "cv", step_size = "lipschitz")
#' }


tlgmm <- function(x, fitted_bar, step_size = c("lipschitz", "fixed"), eta_beta = 0.1, C_lambda0 = 1,
                  lambda_choice = c("fixed", "cv"), cv_nfolds = 10, cv_upper = 10, cv_lower = 0.01, cv_length = 10,
                  kappa0 = 1/3, tol = 1e-5, initial_method = c("kmeans", "EM"), iter_max = 1000, iter_max_prox = 100,
                  ncores = 1) {

  lambda_choice <- match.arg(lambda_choice)
  step_size <- match.arg(step_size)
  initial_method <- match.arg(initial_method)
  mtl_initial_beta <- fitted_bar$initial_beta


  # basic parameters
  K <- length(fitted_bar$w)
  p <- ncol(x)
  n <- nrow(x)
  i <- 1 # just to avoid the error message "no visible binding for global variable 'i'"

  registerDoParallel(ncores)
  # cl <- makeCluster(ncores, outfile="")


  # initialization and alignment adjustment
  # ---------------------------------------------
  fitted_values <- initialize(list(x), initial_method)

  score1 <- score_beta(c(1, rep(1, K)), beta = cbind(mtl_initial_beta, fitted_values$beta))
  score2 <- score_beta(c(-1, rep(1, K)), beta = cbind(mtl_initial_beta, fitted_values$beta))

  if (score2 < score1) { # swap two clusters of target data
    fitted_values <- alignment_swap(-1, initial_value_list = fitted_values)
  }


  # TL-EM
  # -------------------------
  w <- fitted_values$w
  mu1 <- fitted_values$mu1
  mu2 <- fitted_values$mu2
  beta <- fitted_values$beta
  Sigma <- fitted_values$Sigma[[1]]

  beta.bar <- fitted_bar$beta_bar

  # we may need to define similar w.t etc...

  if (lambda_choice == "cv") {
    folds_index <- createFolds(1:n, k = cv_nfolds, list = TRUE)

    if (cv_upper != "auto") {
      C_lambda0.list <- exp(seq(log(cv_lower), log(cv_upper), length.out = cv_length))
    } else {
      C_lambda0_up <- 1000
      C_lambda0_low <- 0
      while(1) {
        C_lambda0 <- (C_lambda0_up + C_lambda0_low)/2
        beta_cur <- beta_fit0(C_lambda0, x, n, w, mu1, mu2, beta, beta.bar, Sigma, p, K, tol, kappa0, iter_max, iter_max_prox, step_size)
        u_diff <- col_norm(beta_cur-beta.bar)
        if (u_diff <= 1e-2) {
          C_lambda0_up <- C_lambda0
        } else {
          C_lambda0_low <- C_lambda0
        }

        if(abs(C_lambda0_up - C_lambda0_low)<=1) {
          C_lambda0 <- C_lambda0_up
          break
        }
        # print(c(C_lambda0, u_diff))
      }
      # print("out!")
      C_lambda0.list <- exp(seq(log(C_lambda0/100*2), log(C_lambda0*2), length.out = cv_length))
    }



    emp_logL <- foreach(i = 1:length(C_lambda0.list), .combine = "rbind", .packages = "mclust") %dopar% {
      sapply(1:cv_nfolds, function(j){
        x.train <- x[-folds_index[[j]], ]
        x.valid <- x[folds_index[[j]], ]
        n.train <- nrow(x.train)
        lambda.t <- C_lambda0.list[i]*sqrt(max(n.train))

        for (l in 1:iter_max) {
          gamma <- as.numeric(w/(w + (1-w)*exp(-t(beta) %*% (t(x.train) - as.numeric(mu1 + mu2)/2))))
          lambda.t <- kappa0*lambda.t + C_lambda0.list[i]*sqrt(p)

          # w
          w.old <- w
          w <- mean(gamma)

          # mu1
          mu1.old <- mu1
          mu1 <- colMeans((1-gamma)*x.train)/(1-w)

          # mu2
          mu2.old <- mu2
          mu2 <- colMeans(gamma*x.train)/w

          # Sigma
          Sigma.old <- Sigma
          Sigma1 <- t(x.train - matrix(rep(mu1, n.train), nrow = n.train, byrow = T)) %*% diag(1-as.numeric(gamma)) %*% (x.train - matrix(rep(mu1, n.train), nrow = n.train, byrow = T))
          Sigma2 <- t(x.train - matrix(rep(mu2, n.train), nrow = n.train, byrow = T)) %*% diag(as.numeric(gamma)) %*% (x.train - matrix(rep(mu2, n.train), nrow = n.train, byrow = T))
          Sigma <- (Sigma1+Sigma2)/n.train


          # beta
          if (l == 1) {
            beta.t <- beta - beta.bar
          }
          beta.bar.old.last.round <- beta.bar

          if (step_size == "lipschitz") {
            eta_beta.list <- 1/(2*norm(Sigma, "2"))
          } else if (step_size == "fixed") {
            eta_beta.list <- eta_beta
          }

          for (r in 1:iter_max_prox) {
            beta.t.old <- beta.t

            eta_beta <- eta_beta.list
            del <- beta.t - eta_beta*(Sigma %*% (beta.t + beta.bar) + mu1 - mu2)
            beta.t <- max(1-(eta_beta*lambda.t/sqrt(n.train))/sqrt(sum(del^2)), 0)*del

            if (col_norm(beta.t - beta.t.old) <= tol) {
              break
            }

          }

          beta.old <- beta
          beta <- beta.t + as.numeric(beta.bar)


          # check whether to terminate the interation process or not
          error <- max(vec_max_norm(w-w.old), vec_norm(mu1 - mu1.old), vec_norm(mu2 - mu2.old), vec_norm(beta - beta.old),
                       norm(Sigma-Sigma.old, "2"))
          if (error <= tol) {
            break
          }
        }
        loss <- sum(log((1-w)*mclust::dmvnorm(data = x.valid, mean = mu1, sigma = Sigma) +
                          w*mclust::dmvnorm(data = x.valid, mean = mu2, sigma = Sigma)))
        loss
      })
    }

    C_lambda0 <- C_lambda0.list[which.max(rowMeans(emp_logL))]
    lambda_choice <- "fixed" # run the algorithm again with optimal choice of parameters
  }

  if (lambda_choice == "fixed") {
    lambda.t <- C_lambda0*sqrt(n)

    for (l in 1:iter_max) {
      gamma <- as.numeric(w/(w + (1-w)*exp(-t(beta) %*% (t(x) - (as.numeric(mu1 + mu2))/2))))

      lambda.t <- kappa0*lambda.t + C_lambda0*sqrt(p)

      # w
      w.old <- w
      w <- mean(gamma)

      # mu1
      mu1.old <- mu1
      mu1 <- colMeans((1-gamma)*x)/(1-w)


      # mu2
      mu2.old <- mu2
      mu2 <- colMeans(gamma*x)/w

      # Sigma
      Sigma.old <- Sigma
      Sigma1 <- t(x - matrix(rep(mu1, n), nrow = n, byrow = T)) %*% diag(1-as.numeric(gamma)) %*% (x - matrix(rep(mu1, n), nrow = n, byrow = T))
      Sigma2 <- t(x - matrix(rep(mu2, n), nrow = n, byrow = T)) %*% diag(as.numeric(gamma)) %*% (x - matrix(rep(mu2, n), nrow = n, byrow = T))
      Sigma <- (Sigma1+Sigma2)/n


      # beta
      if (l == 1) {
        beta.t <- beta - beta.bar
      }
      beta.bar.old.last.round <- beta.bar

      if (step_size == "lipschitz") {
        eta_beta.list <- 1/(2*norm(Sigma, "2"))
      } else if (step_size == "fixed") {
        eta_beta.list <- eta_beta
      }

      for (r in 1:iter_max_prox) {
        beta.t.old <- beta.t

        eta_beta <- eta_beta.list
        del <- beta.t - eta_beta*(Sigma %*% (beta.t + beta.bar) + mu1 - mu2)
        beta.t <- max(1-(eta_beta*lambda.t/sqrt(n))/sqrt(sum(del^2)), 0)*del

        if (col_norm(beta.t - beta.t.old) <= tol) {
          break
        }

      }

      beta.old <- beta
      beta <- beta.t + as.numeric(beta.bar)

      # check whether to terminate the interation process or not
      error <- max(vec_max_norm(w-w.old), vec_norm(mu1 - mu1.old), vec_norm(mu2 - mu2.old), vec_norm(beta - beta.old),
                   norm(Sigma-Sigma.old, "2"))
      if (error <= tol) {
        break
      }
    }
  }


  stopImplicitCluster()
  # stopCluster(cl)

  delta <- sum(beta*(mu1+mu2)/2)

  return(list(w = w, mu1 = mu1, mu2 = mu2, beta = beta, delta = delta, Sigma = Sigma, C_lambda0 = C_lambda0))


}
