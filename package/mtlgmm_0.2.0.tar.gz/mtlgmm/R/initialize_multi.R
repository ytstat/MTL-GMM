#' @title Initialize the estimators of multi-component GMM parameters on each task.
#'
#' @description Initialize the estimators of multi-component GMM parameters on each task.
#' @export
#' @param x design matrices from multiple data sets. Should be a list, of which each component is a \code{matrix} or \code{data.frame} object, representing the design matrix from each task.
#' @param method initialization method. This indicates the method to initialize the estimates of GMM parameters for each data set. Can be either "EM" or "kmeans". Default: "EM".
#' \itemize{
#' \item EM: the initial estimates of GMM parameters will be generated from the single-task EM algorithm. Will call \code{\link[mclust]{Mclust}} function in \code{mclust} package.
#' \item kmeans: the initial estimates of GMM parameters will be generated from the single-task k-means algorithm. Will call \code{\link[stats]{kmeans}} function in \code{stats} package.
#' }
#' @param R the number of clusters for tasks. If the number of clusters are identical in all non-outlier tasks, then input \code{R} as a positive integer. If the number of clusters are different across non-outlier tasks, then input \code{R} as a vector indicating the number of tasks for each task. Default = 4.
#' @param diff_R whether the cluster numbers of tasks are different. Default: \code{FALSE}. The case that it is TRUE corresponds to the extension in Section S.3.1 in the supplement of Tian, Y. et al. (2022).
#' @return A list with the following components.
#' \item{w}{the estimate of mixture proportion in GMMs for each task. Will be a vector.}
#' \item{mu}{the estimate of Gaussian mean in the first cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{Sigma}{the estimate of the common covariance matrix for each task. Will be a list, where each component represents the estimate for a task.}
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @examples
#' set.seed(0, kind = "L'Ecuyer-CMRG")
#' ## Consider a 5-task multi-task learning problem in the setting "MTL-1"
#' data_list <- data_generation(K = 5, outlier_K = 1, simulation_no = "MTL-1",
#' h = 1, n = 50)  # generate the data
#'
#' ## Initialize the estimators of GMM parameters on each task.
#' fitted_values_EM <- initialize(data_list$data$x,
#' "EM")  # initilize the estimates by single-task EM algorithm
#' fitted_values_kmeans <- initialize(data_list$data$x,
#' "kmeans")  # initilize the estimates by single-task k-means

initialize_multi <- function(x, method = c("kmeans", "EM"), R = 4, diff_R = FALSE) {
  method <- match.arg(method)
  K <- length(x)
  k <- NULL # just to avoid the error message "no visible binding for global variable 'i'"

  if (!diff_R) { # R needs to be a number
    if (method == "kmeans") {
      fit_kmeans <- sapply(1:K, function(k){kmeans(x[[k]], centers = R)}, simplify = FALSE)

      w_0 <- sapply(1:K, function(k){
        fit_kmeans[[k]]$size/nrow(x[[k]])
      })

      mu_0 <- sapply(1:R, function(r){
        sapply(1:K, function(k){
          fit_kmeans[[k]]$centers[r,]
        })
      }, simplify = FALSE)

      Sigma_0 <- sapply(1:K, function(k){
        Sigma <- sapply(1:R, function(r){
          w_0[r, k]*t(x[[k]][fit_kmeans[[k]]$cluster == r, ] - matrix(rep(mu_0[[r]][, k], each = sum(fit_kmeans[[k]]$cluster == r)), ncol = ncol(x[[k]]))) %*%
            (x[[k]][fit_kmeans[[k]]$cluster == r, ] - matrix(rep(mu_0[[r]][, k], each = sum(fit_kmeans[[k]]$cluster == r)), ncol = ncol(x[[k]])))
        }, simplify = FALSE)
        Reduce("+", Sigma)
      }, simplify = FALSE)
    } else if (method == "EM") {
      # fit_mcluster <- quiet(sapply(1:K, function(k){
      #   Mclust(x[[k]], G = R, modelNames = "EEE")
      # }, simplify = FALSE))

      invisible(capture.output(fit_mcluster <- sapply(1:K, function(k){
        Mclust(x[[k]], G = R, modelNames = "EEE")
      }, simplify = FALSE)))

      w_0 <- t(sapply(1:R, function(r){
        sapply(1:K, function(k){
          fit_mcluster[[k]]$parameters$pro[r]
        })
      }))

      mu_0 <- sapply(1:R, function(r){
        sapply(1:K, function(k){
          fit_mcluster[[k]]$parameters$mean[, r]
        })
      }, simplify = FALSE)



      Sigma_0 <- sapply(1:K, function(k){
        fit_mcluster[[k]]$parameters$variance$Sigma
      }, simplify = FALSE)
    }
  } else { # diff_R = TRUE: R needs to be a vector
    if (method == "kmeans") {
      fit_kmeans <- sapply(1:K, function(k){kmeans(x[[k]], centers = R[k])}, simplify = FALSE)

      w_0 <- sapply(1:K, function(k){
        fit_kmeans[[k]]$size/nrow(x[[k]])
      })

      mu_0 <- sapply(1:R[k], function(r){
        sapply(1:K, function(k){
          fit_kmeans[[k]]$centers[r,]
        })
      }, simplify = FALSE)

      Sigma_0 <- sapply(1:K, function(k){
        Sigma <- sapply(1:R[k], function(r){
          w_0[r, k]*t(x[[k]][fit_kmeans[[k]]$cluster == r, ] - matrix(rep(mu_0[[r]][, k], each = sum(fit_kmeans[[k]]$cluster == r)), ncol = ncol(x[[k]]))) %*%
            (x[[k]][fit_kmeans[[k]]$cluster == r, ] - matrix(rep(mu_0[[r]][, k], each = sum(fit_kmeans[[k]]$cluster == r)), ncol = ncol(x[[k]])))
        }, simplify = FALSE)
        Reduce("+", Sigma)
      }, simplify = FALSE)
    } else if (method == "EM") {
      invisible(capture.output(fit_mcluster <- sapply(1:K, function(k){
        Mclust(x[[k]], G = R[k], modelNames = "EEE")
      }, simplify = FALSE)))

      w_0 <- sapply(1:K, function(k){
        sapply(1:R[k], function(r){
          fit_mcluster[[k]]$parameters$pro[r]
        })
      }, simplify = FALSE)

      mu_0 <- sapply(1:K, function(k){
        sapply(1:R[k], function(r){
          fit_mcluster[[k]]$parameters$mean[, r]
        })
      }, simplify = FALSE)

      Sigma_0 <- sapply(1:K, function(k){
        fit_mcluster[[k]]$parameters$variance$Sigma
      }, simplify = FALSE)

    }
  }


  return(list(w = w_0, mu = mu_0, Sigma = Sigma_0))
}
