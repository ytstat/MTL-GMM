#' @title Caluclate the estimation error of multi-component GMM parameters under the MTL setting (the worst performance among all non-outlier tasks).
#'
#' @description Caluclate the estimation error of GMM parameters under the MTL setting (the worst performance among all non-outlier tasks). Euclidean norms are used.
#' @export
#' @param estimated_value estimate of GMM parameters. The form of input depends on the parameter \code{parameter}.
#' @param true_value true values of GMM parameters. The form of input depends on the parameter \code{parameter}.
#' @param parameter which parameter to calculate the estimation error for. Can be "w", "mu", "beta", or "Sigma".
#' \itemize{
#' \item w: the Gaussian mixture proportions. Both \code{estimated_value} and \code{true_value} require an input of a R-by-K matrix, where R is the number of GMM clusters and K is the number of tasks.
#' \item mu: Gaussian mean parameters. Both \code{estimated_value} and \code{true_value} require an input of a list of R p-by-K matrices, where p is the dimension of Gaussian distribution, K is the number of tasks, and R is the number of GMM clusters. Each element of the list is a "mu" (estimate or true value) for each task.
#' \item beta: discriminant coefficients. Both \code{estimated_value} and \code{true_value} require an input of a list of two elements, which refers to "mu" and "Sigma", respectively.
#' \item delta: part of the intercept in the decision boundary. Both \code{estimated_value} and \code{true_value} require an input of a R-by-K matrix, where R is the number of GMM clusters and K is the number of tasks.
#' \item Sigma: Gaussian covariance matrices. Both \code{estimated_value} and \code{true_value} require an input of a list of K p-by-p matrices, where p is the dimension of Gaussian distribution and K is the number of tasks. Each matrix in the list is a "Sigma" (estimate or true value) for each task.
#' }
#' @param outlier_index the index of outlier tasks. Default: \code{NULL} (i.e., no outliers).
#' @param diff_R whether the cluster numbers of tasks are different. Default: \code{FALSE}. The case that it is TRUE corresponds to the extension in Section S.3.1 in the supplement of Tian, Y. et al. (2022).
#' @return the largest estimation error among all tasks.
#' @note For examples, see examples in function \code{\link{mtlgmm}}.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{alignment_swap}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., Xia, L., & Feng, Y. (2022). Robust unsupervised multi-task and transfer learning on gaussian mixture models. arXiv preprint arXiv:2209.15224.
#'

estimation_error_multi <- function(estimated_value, true_value, parameter = c("w", "mu", "beta", "delta", "Sigma"), outlier_index = NULL, diff_R = FALSE) {

  if (!diff_R) {
    if (parameter == "w") {
      R <- nrow(estimated_value)
      K <- ncol(estimated_value)
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }

      pi_all <- permutations(R, R)
      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        min(sapply(1:nrow(pi_all), function(i){
          max(abs(estimated_value[pi_all[i, ], k] - true_value[, k]))
        }))
      }))
      return(v)
    } else if (parameter == "mu") {
      R <- length(estimated_value)
      K <- ncol(estimated_value[[1]])
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }
      pi_all <- permutations(R, R)
      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        min(sapply(1:nrow(pi_all), function(i){
          max(sapply(1:R, function(r){
            vec_norm(estimated_value[[pi_all[i, r]]][, k] - true_value[[r]][, k])
          }))
        }))
      }))
      return(v)
    } else if (parameter == "beta") { # in this case, the true_value should be a list containing both true mu and Sigma
      R <- length(estimated_value)
      K <- ncol(estimated_value[[1]])
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }
      pi_all <- permutations(R, R)
      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        min(sapply(1:nrow(pi_all), function(i){
          max(sapply(2:R, function(r){
            # vec_norm(estimated_value[[pi_all[i, r]]][, k] - solve(true_value[[2]][[k]])%*%(true_value[[1]][[r]][, k] - true_value[[1]][[1]][, k]))
            vec_norm(estimated_value[[r]][, k] - solve(true_value[[2]][[k]])%*%(true_value[[1]][[pi_all[i, r]]][, k] - true_value[[1]][[pi_all[i, 1]]][, k]))
          }))
        }))
      }))
      return(v)
    } else if (parameter == "delta") {
      R <- nrow(estimated_value)
      K <- ncol(estimated_value)
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }
      pi_all <- permutations(R, R)
      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        min(sapply(1:nrow(pi_all), function(i){
          max(sapply(2:R, function(r){
            # abs(estimated_value[pi_all[i, r], k] - t(true_value[[1]][[r]][, k] - true_value[[1]][[1]][, k]) %*% solve(true_value[[2]][[k]]) %*% (true_value[[1]][[r]][, k] + true_value[[1]][[1]][, k])/2)
            abs(estimated_value[r, k] - t(true_value[[1]][[pi_all[i, r]]][, k] - true_value[[1]][[pi_all[i, 1]]][, k]) %*% solve(true_value[[2]][[k]]) %*% (true_value[[1]][[pi_all[i, r]]][, k] + true_value[[1]][[pi_all[i, 1]]][, k])/2)
          }))
        }))
      }))
      return(v)
    } else if (parameter == "Sigma") {
      K <- length(estimated_value)
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }

      err <- max(sapply(setdiff(1:K, outlier_index), function(k){
        norm(estimated_value[[k]]-true_value[[k]], "2")
      }))
      return(max(err))
    }
  } else { # diff_R = TRUE
    if (parameter == "w") {
      K <- ncol(estimated_value)
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }
      w_hat <- sapply(1:K, function(k){
        estimated_value[!is.na(estimated_value[,k]),k]
      }, simplify = F)

      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        R <- length(w_hat[[k]])
        pi_all <- permutations(R, R)
        min(sapply(1:nrow(pi_all), function(i){
          max(abs(w_hat[[k]][pi_all[i, ]] - true_value[[k]]))
        }))
      }))
      return(v)
    } else if (parameter == "mu") {
      R_max <- length(estimated_value)
      K <- ncol(estimated_value[[1]])
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }

      mu_hat <- sapply(1:K, function(k){
        mu_na <- sapply(1:R_max, function(r){
          estimated_value[[r]][, k]
        })
        mu_na[, !apply(mu_na, 2, function(x){anyNA(x)})]
      }, simplify = F)

      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        R <- ncol(mu_hat[[k]])
        pi_all <- permutations(R, R)
        min(sapply(1:nrow(pi_all), function(i){
          max(sapply(1:R, function(r){
            vec_norm(mu_hat[[k]][, pi_all[i, r]] - true_value[[k]][, r])
          }))
        }))
      }))
      return(v)
    } else if (parameter == "beta") {
      R_max <- length(estimated_value)
      K <- ncol(estimated_value[[1]])

      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }

      beta_hat <- sapply(1:K, function(k){
        beta_na <- sapply(1:R_max, function(r){
          estimated_value[[r]][, k]
        })
        beta_na[, !apply(beta_na, 2, function(x){anyNA(x)})]
      }, simplify = F)


      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        R <- ncol(beta_hat[[k]])
        pi_all <- permutations(R, R)
        min(sapply(1:nrow(pi_all), function(i){
          max(sapply(2:R, function(r){
            vec_norm(beta_hat[[k]][, r] - solve(true_value[[2]][[k]])%*%(true_value[[1]][[k]][, pi_all[i, r]] - true_value[[1]][[k]][, pi_all[i, 1]]))
          }))
        }))
      }))
      return(v)
    } else if (parameter == "delta") {
      K <- ncol(estimated_value)
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }

      R_max <- nrow(estimated_value)

      delta_hat <- sapply(1:K, function(k){
        estimated_value[!is.na(estimated_value[,k]),k]
      }, simplify = F)

      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        R <- length(delta_hat[[k]])
        pi_all <- permutations(R, R)
        min(sapply(1:nrow(pi_all), function(i){
          max(sapply(2:R, function(r){
            abs(delta_hat[[k]][r] - t(true_value[[1]][[k]][, pi_all[i, r]] - true_value[[1]][[k]][, pi_all[i, 1]]) %*% solve(true_value[[2]][[k]]) %*% (true_value[[1]][[k]][, pi_all[i, r]] + true_value[[1]][[k]][, pi_all[i, 1]])/2)
          }))
        }))
      }))

      return(v)
    } else if (parameter == "Sigma") {
      K <- length(estimated_value)
      if (is.null(outlier_index)) {
        outlier_index <- K+1
      }

      v <- max(sapply(setdiff(1:K, outlier_index), function(k){
        norm(estimated_value[[k]]-true_value[[k]], "2")
      }))
      return(v)
    }
  }


}


