#' @title Complete the alignment of initializations based on the output of function \code{\link{alignment_multi}}.
#'
#' @description Complete the alignment of initializations based on the output of function \code{\link{alignment_multi}}. This function is mainly for people to align the single-task initializations manually. The alignment procedure has been automatically implemented in function \code{mtlgmm_multi}. So there is no need to call this function when fitting MTL-GMM.
#' @export
#' @param pihat the output from function \code{\link{alignment_multi}}
#' @param initial_value_list the output from function \code{\link{initialize_multi}}
#' @param diff_R whether the cluster numbers of tasks are different. Default: \code{FALSE}. The case that it is TRUE corresponds to the extension in Section S.3.1 in the supplement of Tian, Y. et al. (2022).
#' @return A list with the following components (well-aligned).
#' \item{w}{the estimate of mixture proportion in GMMs for each task. Will be a vector.}
#' \item{mu1}{the estimate of Gaussian mean in the first cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{mu2}{the estimate of Gaussian mean in the second cluster of GMMs for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{beta}{the estimate of the discriminant coefficient for each task. Will be a matrix, where each column represents the estimate for a task.}
#' \item{Sigma}{the estimate of the common covariance matrix for each task. Will be a list, where each component represents the estimate for a task.}
#' @note For examples, see part "fit signle-task GMMs" of examples in function \code{\link{mtlgmm}}.
#' @seealso \code{\link{mtlgmm}}, \code{\link{tlgmm}}, \code{\link{predict_gmm}}, \code{\link{data_generation}}, \code{\link{initialize}}, \code{\link{alignment}}, \code{\link{estimation_error}}, \code{\link{misclustering_error}}.
#' @references
#' Tian, Y., Weng, H., & Feng, Y. (2022). Unsupervised Multi-task and Transfer Learning on Gaussian Mixture Models. arXiv preprint arXiv:2209.15224.
#'

alignment_swap_multi <- function(pihat, initial_value_list, diff_R = FALSE) {
  if (!diff_R) {
    K <- ncol(initial_value_list$w)
    R <- nrow(initial_value_list$w)
    p <- nrow(initial_value_list$mu[[1]])
    initial_value_list_new <- initial_value_list
    for (k in 1:K) {
      for (r in 1:R) {
        initial_value_list_new$w[r, k] <- initial_value_list$w[pihat[r, k]]
        initial_value_list_new$mu[[r]][, k] <- initial_value_list$mu[[pihat[r, k]]][, k]
      }
    }

    initial_value_list_new$beta <- rep(list(matrix(0, nrow = p, ncol = K)), R)
    initial_value_list_new$Sigma <- initial_value_list$Sigma
    for (k in 1:K) {
      for (r in 2:R) {
        initial_value_list_new$beta[[r]][, k] <- solve(initial_value_list$Sigma[[k]]) %*% (initial_value_list_new$mu[[r]][, k] - initial_value_list_new$mu[[1]][, k])
      }
    }

    initial_value_list_new$delta <- matrix(0, nrow = R, ncol = K)
    for (k in 1:K) {
      for (r in 2:R) {
        initial_value_list_new$delta[r, k] <- t(initial_value_list_new$beta[[r]][, k]) %*% (initial_value_list_new$mu[[r]][, k] + initial_value_list_new$mu[[1]][, k])/2
      }
    }
  } else { # diff_R = TRUE
    K <- nrow(pihat)
    R_max <- ncol(pihat)
    p <- nrow(initial_value_list$mu[[1]])
    initial_value_list_new <- list(w = matrix(nrow = R_max, ncol = K),
                                   mu = rep(list(matrix(nrow = p, ncol = K)), R_max),
                                   beta = rep(list(matrix(nrow = p, ncol = K)), R_max),
                                   delta = matrix(nrow = R_max, ncol = K))
    for (k in 1:K) {
      for (r in 1:R_max) {
        if (!is.na(pihat[k, r])) {
          initial_value_list_new$w[r, k] <- initial_value_list$w[[k]][pihat[k, r]]
          initial_value_list_new$mu[[r]][, k] <- initial_value_list$mu[[k]][, pihat[k, r]]
          if (r == 1) {
            initial_value_list_new$beta[[r]] <- matrix(0, nrow = p, ncol = K)
            initial_value_list_new$delta[r, ] <- 0
          } else {
            initial_value_list_new$beta[[r]][, k] <- solve(initial_value_list$Sigma[[k]]) %*% (initial_value_list_new$mu[[r]][, k] - initial_value_list_new$mu[[1]][, k])
            initial_value_list_new$delta[r, k] <- t(initial_value_list_new$beta[[r]][, k]) %*% (initial_value_list_new$mu[[r]][, k] + initial_value_list_new$mu[[1]][, k])/2
          }
        }

      }
    }
    initial_value_list_new$Sigma <- initial_value_list$Sigma
  }

  return(initial_value_list_new)
}

